"""
Generates all ISAA Chain JSON files for /chain import.
Run: python gen_chains.py
Output: chains/ directory with individual + bundle JSON.
"""
import json, hashlib, datetime
from pathlib import Path

OUT = Path("chains")
OUT.mkdir(exist_ok=True)

def chain_id(name: str, dsl: str) -> str:
    return hashlib.sha256(f"{name}:{dsl}".encode()).hexdigest()[:12]

def make(name, dsl, description, tags):
    return {
        "id":               chain_id(name, dsl),
        "name":             name,
        "dsl":              dsl,
        "description":      description,
        "accepted":         False,
        "created_at":       datetime.datetime.now().isoformat(),
        "last_run":         None,
        "run_count":        0,
        "tags":             tags,
        "is_valid":         True,
        "validation_errors":[],
        "custom_functions": [],
        "referenced_tools": [],
        "uses_agents":      True,
    }

# ─────────────────────────────────────────────────────────────────────────────
# 1. DEPENDENCY AUDIT
# ─────────────────────────────────────────────────────────────────────────────
DEP_AUDIT = make(
    name="dep_audit",
    dsl=(
        '@self("You are a dependency auditor. The input is a project root path. '
        'Step 1 — READ: Use shell_exec to run: cat <path>/pyproject.toml '
        'Step 2 — ANALYZE: For every dependency in [project.dependencies] and '
        '[tool.uv.dev-dependencies]: use web_search to find: '
        '(a) latest stable version on PyPI, '
        '(b) any CVEs in the currently pinned version (search NVD + GitHub advisories), '
        '(c) breaking changes between current and latest (check CHANGELOG or release notes). '
        'Step 3 — CLASSIFY each dep into: '
        'SAFE_UPDATE (no breaking changes, no CVE), '
        'NEEDS_REVIEW (breaking changes OR major version bump), '
        'CVE_CRITICAL (active CVE, update immediately). '
        'Step 4 — EXECUTE safe updates: for each SAFE_UPDATE dep run: '
        'shell_exec(uv add <pkg>==<latest_version> --directory <path>) '
        'Then verify: shell_exec(cd <path> && uv run python -c \"import <pkg>\") '
        'Step 5 — OUTPUT structured report: '
        '{updated:[{name,old,new}], cve_critical:[{name,cve_id,severity,fix}], '
        'needs_review:[{name,reason,changelog_url}], failed:[{name,error}]}")'
    ),
    description=(
        "Liest pyproject.toml, prüft alle Deps auf Updates+CVEs via web_search, "
        "führt sichere Updates mit uv aus, verifiziert Imports, gibt strukturierten Bericht zurück. "
        "Input: Projektpfad (z.B. /home/markin/ToolBoxV2)."
    ),
    tags=["deps", "security", "uv", "audit", "maintenance"],
)

# ─────────────────────────────────────────────────────────────────────────────
# 2. SECURITY SCANNER (Docker + Codebase)
# ─────────────────────────────────────────────────────────────────────────────
SEC_SCAN = make(
    name="security_scanner",
    dsl=(
        '@self("You are a security auditor. Input is a project root path. '
        'PART A — DOCKERFILE AUDIT: '
        'shell_exec(cat <path>/Dockerfile) '
        'Check: (1) Base image — use web_search to find latest digest + known CVEs for that image tag. '
        '(2) Is the image pinned by digest (SHA256) or only by tag? Tags are mutable — flag if not pinned. '
        '(3) Are secrets or tokens present in ENV or ARG instructions? '
        '(4) Is the container running as root (no USER instruction)? '
        '(5) Are unnecessary packages installed (curl, wget, git in prod image)? '
        '(6) Multi-stage build used to minimize attack surface? '
        'PART B — CODE SECURITY: '
        'shell_exec(grep -rn \"exec(\\|eval(\\|subprocess.shell=True\\|pickle.load\\|yaml.load(\" <path>/toolboxv2 --include=\"*.py\" -l) '
        'For each flagged file: read the relevant lines and assess severity. '
        'shell_exec(grep -rn \"password\\|secret\\|api_key\\|token\" <path>/toolboxv2 --include=\"*.py\" -l | grep -v test | grep -v \".pyc\") '
        'PART C — DEPENDENCY CVEs: '
        'shell_exec(cd <path> && uv run pip-audit --format json 2>/dev/null || echo \"pip-audit not installed\") '
        'If pip-audit missing: use web_search for top 5 deps from pyproject.toml + \"CVE 2024 2025\". '
        'OUTPUT — structured report with severity levels CRITICAL/HIGH/MEDIUM/LOW: '
        '{dockerfile:[{issue,severity,line,fix}], code:[{file,line,pattern,risk,fix}], '
        'deps:[{name,cve,severity,fix_version}], score:\"X/10 security score\"}")'
    ),
    description=(
        "Vollständiger Security Audit: Dockerfile (Base-Image CVEs, Root-User, Secrets, Pinning), "
        "Code-Patterns (eval, pickle, hardcoded secrets), Dependency CVEs. "
        "Input: Projektpfad."
    ),
    tags=["security", "docker", "cve", "audit", "hardening"],
)

# ─────────────────────────────────────────────────────────────────────────────
# 3. DEEP RESEARCH
# ─────────────────────────────────────────────────────────────────────────────
DEEP_RESEARCH = make(
    name="deep_research",
    dsl=(
        '@self("PHASE 1 — SCOPING: The input is a research question or topic. '
        'Break it into 4-6 specific sub-questions that together fully answer the main question. '
        'For each sub-question: what source type is best (academic, news, docs, forum)?") >> '
        '(@self("Search and answer sub-question 1 from the scope. Use web_search 2-3 times with different query angles. Synthesize findings. Output: {sub_q, findings, sources:[url], confidence:high/med/low}") + '
        '@self("Search and answer sub-question 2 from the scope. Use web_search 2-3 times with different query angles. Synthesize findings. Output: {sub_q, findings, sources:[url], confidence:high/med/low}")) >> '
        '@self("You have parallel research results from multiple sub-questions. '
        'SYNTHESIS: '
        '1. Identify agreements, contradictions, and gaps across all findings. '
        '2. Weight sources by credibility (peer-reviewed > official docs > reputable news > forums). '
        '3. Write a structured research report in Markdown: '
        '# <Topic>\\n'
        '## Executive Summary (3-5 sentences)\\n'
        '## Key Findings (one section per sub-question)\\n'
        '## Contradictions & Open Questions\\n'
        '## Sources\\n'
        '## Confidence Assessment\\n")'
        ' >> '
        '@self("Save the research report to the Obsidian vault. '
        'Use shell_exec: mkdir -p /srv/obsidian/vaults/main/Research && '
        'Generate a filename: Research/<topic_slug>_<YYYY-MM-DD>.md '
        'Write the full markdown report to that file using shell_exec with a heredoc or Python one-liner. '
        'Confirm: shell_exec(ls /srv/obsidian/vaults/main/Research/) '
        'Return: {saved_to, word_count, key_finding_summary}")'
    ),
    description=(
        "4-6 Sub-Fragen Scope → parallele Web-Recherche → Synthese → strukturierter Markdown-Report "
        "→ gespeichert im Obsidian Vault unter Research/. Input: Forschungsfrage oder Thema."
    ),
    tags=["research", "web", "obsidian", "synthesis", "knowledge"],
)

# ─────────────────────────────────────────────────────────────────────────────
# 4. LEARNING PATH
# ─────────────────────────────────────────────────────────────────────────────
LEARNING_PATH = make(
    name="learning_path",
    dsl=(
        '@self("Input is a topic to learn. '
        'Step 1 — ASSESS LANDSCAPE: Use web_search to find: '
        '(a) Prerequisites for this topic, '
        '(b) Standard learning progression (beginner → expert), '
        '(c) Best resources in 2024/2025 (courses, books, docs, practice platforms). '
        'Step 2 — STRUCTURE: Create a 4-phase learning path: '
        'Phase 1: Foundations (1-2 weeks), Phase 2: Core Concepts (2-4 weeks), '
        'Phase 3: Applied Practice (ongoing), Phase 4: Advanced / Specialization. '
        'For each phase: specific resources with URLs, concrete exercises, milestone to verify learning. '
        'Step 3 — PERSONALIZE: Consider a CS student / senior developer context. '
        'Skip basics they already know (programming fundamentals, git, etc.). '
        'Step 4 — WRITE to Obsidian: '
        'shell_exec to write to /srv/obsidian/vaults/main/Learning/<topic_slug>.md '
        'Format: # Learning Path: <topic>\\n## Prerequisites\\n## Phase 1...4\\n## Resources\\n## Milestones\\n '
        'Return: {path, phases:4, estimated_weeks, key_resources:[{title,url,type}]}")'
    ),
    description=(
        "Recherchiert optimalen Lernpfad für ein Thema → 4 Phasen mit Resources, Übungen, Milestones "
        "→ gespeichert in Obsidian unter Learning/. Input: Thema (z.B. 'Rust async', 'Kubernetes')."
    ),
    tags=["learning", "education", "obsidian", "roadmap", "resources"],
)

# ─────────────────────────────────────────────────────────────────────────────
# 5. FEATURE SPEC
# ─────────────────────────────────────────────────────────────────────────────
FEATURE_SPEC = make(
    name="feature_spec",
    dsl=(
        '@self("Input is a feature idea for ToolBoxV2 or SimpleCore. '
        'Step 1 — UNDERSTAND: What problem does this solve? Who uses it? What is the success metric? '
        'Step 2 — RESEARCH: web_search for similar features in comparable open-source projects. '
        'What patterns exist? What pitfalls are common? '
        'Step 3 — WRITE SPEC in this exact structure: '
        '# Feature: <Name>\\n'
        '## Problem Statement\\n'
        '## Target Users & Use Cases\\n'
        '## User Stories\\n(as <user> I want <action> so that <benefit>)\\n'
        '## Acceptance Criteria\\n(Given/When/Then format)\\n'
        '## Technical Design\\n(components, data flow, API surface, integration points)\\n'
        '## Out of Scope\\n'
        '## Open Questions\\n'
        '## Effort Estimate\\n(S/M/L/XL + reasoning)\\n")'
        ' >> '
        '@self("Review the spec critically: '
        '1. Are all acceptance criteria testable and unambiguous? '
        '2. Are there missing edge cases or error states? '
        '3. Does the technical design fit ToolBoxV2 architecture (modular, tb_root, get_app() pattern)? '
        '4. Any scope creep? Flag it. '
        'Output the REVISED spec with a ## Review Notes section added. Then: '
        'shell_exec to save to /srv/obsidian/vaults/main/Specs/<feature_slug>.md '
        'Return: {saved_to, user_stories_count, acceptance_criteria_count, effort_estimate}")'
    ),
    description=(
        "Idee → vollständige Feature-Spec (Problem, User Stories, Acceptance Criteria, Tech Design) "
        "→ Self-Review → gespeichert in Obsidian Specs/. Input: Feature-Idee als Freitext."
    ),
    tags=["spec", "feature", "simplecore", "toolboxv2", "planning", "obsidian"],
)

# ─────────────────────────────────────────────────────────────────────────────
# 6. TOOLBOX MOD BUILDER
# ─────────────────────────────────────────────────────────────────────────────
MOD_BUILDER = make(
    name="tb_mod_builder",
    dsl=(
        '@self("Input is a mod description or name. '
        'Step 1 — READ CONVENTIONS: '
        'shell_exec(cat <tb_root>/toolboxv2/mods/cloudM/__init__.py | head -80) '
        'shell_exec(cat <tb_root>/toolboxv2/mods/__init__.py | head -40) '
        'Understand: how mods register, the @App.mod_export pattern, get_app(), version format. '
        'Step 2 — DESIGN: Based on the input description, design the mod: '
        '(a) Module name and version, (b) exported functions/classes, '
        '(c) dependencies (existing toolboxv2 utils to reuse), '
        '(d) data storage (MinIO, SQLite, or in-memory), '
        '(e) API endpoints if needed. '
        'Step 3 — GENERATE the complete __init__.py for the mod. '
        'Include: module docstring, version, all exports, error handling, logging. '
        'Follow the 50-lines-not-500 philosophy: minimal but complete. '
        'Output ONLY the code — no explanation.")'
        ' >> '
        '@self("You have a designed mod. Now implement it. '
        'Use shell_exec to: '
        '1. Create the directory: mkdir -p <tb_root>/toolboxv2/mods/<mod_name> '
        '2. Write the __init__.py '
        '3. Run: cd <tb_root> && python -c \"from toolboxv2.mods.<mod_name> import *\" to verify import '
        '4. If import fails: read the error, fix the code, retry. '
        'Return: {mod_path, exports:[], import_ok:bool, next_steps}")'
    ),
    description=(
        "Liest ToolBoxV2 Mod-Konventionen → designed neuen Mod → implementiert __init__.py "
        "→ verifiziert Import. Input: Mod-Beschreibung (z.B. 'Rate limiter für externe APIs')."
    ),
    tags=["toolboxv2", "mod", "builder", "coder", "development"],
)

# ─────────────────────────────────────────────────────────────────────────────
# 7. MOD REFINER
# ─────────────────────────────────────────────────────────────────────────────
MOD_REFINER = make(
    name="tb_mod_refiner",
    dsl=(
        '@self("Input is a path to an existing ToolBoxV2 mod or mod name. '
        'Step 1 — READ: shell_exec(cat <mod_path>/__init__.py) '
        'Step 2 — ANALYZE against these criteria: '
        '(a) Code quality: complexity, duplication, unclear names '
        '(b) ToolBoxV2 conventions: uses get_app()? proper @export decorators? version set? '
        '(c) Error handling: all external calls wrapped? meaningful error messages? '
        '(d) Performance: unnecessary blocking calls? missing async? '
        '(e) Security: input validation? no hardcoded secrets? '
        '(f) Testability: pure functions where possible? injectable dependencies? '
        'Output: {issues:[{category,line,description,severity:critical/high/med/low}], score:X/10}")'
        ' >> '
        '@self("You have an analysis of a ToolBoxV2 mod with specific issues. '
        'For each CRITICAL and HIGH severity issue: '
        '1. Show the problematic code snippet. '
        '2. Explain why it is an issue. '
        '3. Write the fixed version. '
        'Then produce the COMPLETE refactored __init__.py — not just the changed parts. '
        'Apply all fixes in one coherent rewrite. '
        'Preserve all existing functionality. '
        'Output ONLY the refactored code.")'
        ' >> '
        '@self("Apply the refactored mod. '
        'shell_exec to write the new code to the mod file (backup first: cp file file.bak). '
        'Verify: python -c import test. '
        'If tests exist: shell_exec(python -m pytest <test_path> -x -q). '
        'Return: {backup_at, issues_fixed:N, import_ok, tests_pass, diff_summary}")'
    ),
    description=(
        "Analysiert bestehenden TB-Mod auf Quality/Convention/Security/Performance Issues "
        "→ vollständiger Rewrite mit allen Fixes → verifiziert Import + Tests. "
        "Input: Mod-Pfad oder Mod-Name."
    ),
    tags=["toolboxv2", "mod", "refactor", "quality", "maintenance"],
)

# ─────────────────────────────────────────────────────────────────────────────
# 8. IDEA MASTER
# ─────────────────────────────────────────────────────────────────────────────
IDEA_MASTER = make(
    name="idea_master",
    dsl=(
        '@self("Input is a rough idea or problem. '
        'DIVERGE — generate 8 distinct interpretations/angles of this idea: '
        '2x practical (build it now), 2x ambitious (1 year vision), '
        '2x adjacent (what else this enables), 2x contrarian (why this is wrong / better alternative). '
        'For each: one sentence essence + one sentence unique value.")'
        ' >> '
        '@self("You have 8 idea angles. '
        'CONVERGE — evaluate each on: '
        'Feasibility (1-5), Impact (1-5), Novelty (1-5), Fit with ToolBoxV2/SimpleCore (1-5). '
        'Score and rank all 8. '
        'Pick the TOP 2. For each top idea: '
        'Write a 1-page concept note: Problem → Solution → Key Insight → First Step → Risk. '
        'Be specific. Name concrete technologies, user groups, measurable outcomes.")'
        ' >> '
        '@self("Take the #1 idea from the evaluation. '
        'CRYSTALLIZE into an actionable brief: '
        '## Idea: <name>\\n'
        '## One-liner: <elevator pitch>\\n'
        '## Core insight: <why this works / what makes it different>\\n'
        '## MVP scope: <smallest thing that proves the idea>\\n'
        '## Week 1 action: <concrete first step you can do today>\\n'
        '## If successful this enables: <downstream possibilities>\\n\\n'
        'Then ask: should I save this to Obsidian Ideas/ and create a Feature Spec for it? '
        'If yes: shell_exec to write to /srv/obsidian/vaults/main/Ideas/<idea_slug>.md '
        'Return: {idea_name, one_liner, week1_action, saved_to}")'
    ),
    description=(
        "Rough idea → 8 Winkel (praktisch/ambitioniert/adjacent/contrarian) → Bewertungsmatrix "
        "→ Top-2 Concept Notes → kristallisiertes Actionable Brief → optional Obsidian Ideas/. "
        "Input: Rohe Idee oder Problem als Freitext."
    ),
    tags=["ideas", "brainstorm", "creativity", "planning", "obsidian"],
)

# ─────────────────────────────────────────────────────────────────────────────
# 9. CHAIN CREATION CHAIN
# ─────────────────────────────────────────────────────────────────────────────
CHAIN_CREATION = make(
    name="chain_creation",
    dsl=(
        '@self("Input is a description of what you want a chain to do. '
        'Step 1 — UNDERSTAND the goal: '
        'What is the input? What is the output? What intermediate steps are needed? '
        'What tools are available (web_search, shell_exec, @self, @coder, tb_run_tests, etc.)? '
        'Are there branches (success/failure paths)? Parallel work? '
        'Step 2 — DESIGN the chain structure as a flow diagram in plain text: '
        'INPUT → step1 → [parallel: step2a + step2b] → step3 → [if X: stepA else: stepB] → OUTPUT '
        'Step 3 — WRITE the DSL. Rules: '
        'Sequential: a >> b >> c '
        'Parallel: (a + b) '
        'Error handling: (a | fallback) '
        'Conditional: IS(key==value) >> true_step % false_step '
        'Agent step: @self(\"instruction\") '
        'Tool step: tool:name(arg=\"value\") '
        'Inline func: def:fn(x) -> expr '
        'Custom model: model:Name(field: type) then CF(Name) - \"field\" '
        'Step 4 — OUTPUT the chain definition as JSON ready for /chain import: '
        '{\"name\":\"<name>\",\"dsl\":\"<dsl>\",\"description\":\"<desc>\",\"tags\":[]} '
        'No extra text — just the JSON.")'
        ' >> '
        '@self("You have a chain definition JSON. '
        'Validate it: '
        '1. Is the DSL syntactically correct? (balanced parentheses, valid operators) '
        '2. Does each @self instruction tell the agent exactly what to do and what to output? '
        '3. Are tool names realistic? (only tools that exist in the agent toolkit) '
        '4. Is the chain atomic? (each step does ONE thing) '
        '5. Does the error path handle the most likely failure? '
        'If issues found: fix the JSON. '
        'Output the FINAL validated JSON. '
        'Then: call create_validate_chain with name, dsl, description, tags from the JSON. '
        'Return: {chain_id, name, is_valid, validation_errors, next_step: \"/chain accept <name>\"}")'
    ),
    description=(
        "Beschreibung → Flow-Diagramm → DSL Design → validiertes Chain-JSON → direkt gespeichert. "
        "Der Agent kennt die komplette DSL-Syntax und validiert vor dem Speichern. "
        "Input: Was soll die Chain tun? (Freitext)"
    ),
    tags=["meta", "chain", "builder", "dsl", "automation"],
)

# ─────────────────────────────────────────────────────────────────────────────
# WRITE FILES
# ─────────────────────────────────────────────────────────────────────────────
all_chains = [
    DEP_AUDIT, SEC_SCAN, DEEP_RESEARCH, LEARNING_PATH,
    FEATURE_SPEC, MOD_BUILDER, MOD_REFINER, IDEA_MASTER, CHAIN_CREATION,
]

for chain in all_chains:
    path = OUT / f"{chain['name']}.json"
    path.write_text(json.dumps(chain, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"✓ {path}")

# Bundle
bundle = {
    "version": "1.0",
    "created_at": datetime.datetime.now().isoformat(),
    "chains": all_chains,
}
bundle_path = OUT / "_bundle_all.json"
bundle_path.write_text(json.dumps(bundle, indent=2, ensure_ascii=False), encoding="utf-8")
print(f"\n✓ Bundle: {bundle_path}")
print(f"  {len(all_chains)} chains total")
print("\nImport all:\n  python gen_chains.py  (this script)")
print("  Then in ICLI:")
for c in all_chains:
    print(f"  /chain import chains/{c['name']}.json")
print("\nOr use the bundle loader — add to load_chain_toolkit enable():")
print("  for c in json.loads(bundle_path.read_text())['chains']:")
print("    store.save(StoredChain.from_dict(c))")

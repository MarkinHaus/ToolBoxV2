"/**
 * omni-chat-bridge.js — Connects omni-bubble events to the ISAA chat UI.
 *
 * Listens for transcript events from omni-bubble.js and persists them to
 * the active chat. This makes voice sessions visible in the chat history
 * alongside text messages.
 *
 * Loaded after omni-bubble.js and app.js.
 */
(function () {
  var Store = (window.ISAA && window.ISAA.Store) || null;
  var Chat = (window.ISAA && window.ISAA.Chat) || null;

  var inputBuffer = '';

  function flushInputBuffer() {
    if (!inputBuffer.trim()) return;
    if (!Store || !Store.activeChatId) return;
    Store.pushFrame({
      type: 'user_msg',
      text: inputBuffer.trim(),
      meta: { voice: true, source: 'omni' },
      _optimistic: true,
    });
    inputBuffer = '';
    rerenderChat();
  }

  function rerenderChat() {
    var view = document.getElementById('view');
    var body = document.querySelector('.isaa-body');
    if (!view || !body || body.dataset.view !== 'chat') return;
    var container = view.querySelector('.chat-container');
    if (container && Chat) {
      Chat.render(container);
      Chat.scrollToBottom(container);
    }
  }

  // Transcript handler: user speech accumulates, agent speech renders immediately
  window.addEventListener('omni-transcript', function (e) {
    if (!e.detail || !e.detail.text) return;
    Store = (window.ISAA && window.ISAA.Store) || null;
    Chat = (window.ISAA && window.ISAA.Chat) || null;
    if (!Store || !Store.activeChatId) return;

    var text = e.detail.text;
    var isAgent = !!e.detail.isAgent;

    if (isAgent) {
      // Flush any buffered user input first
      flushInputBuffer();
      // Push agent text as content chunk
      Store.pushFrame({
        type: 'content',
        chunk: text,
        meta: { voice: true, source: 'omni' },
      });
    } else {
      // Accumulate user speech (flushed on state change to speaking/idle)
      inputBuffer += text;
    }
    rerenderChat();
  });

  // State change handler: flush buffered user input when model starts speaking
  window.addEventListener('omni-state-change', function (e) {
    if (!e.detail || !e.detail.state) return;
    var s = e.detail.state;
    if (s === 'speaking' || s === 'idle') {
      flushInputBuffer();
    }
  });

  console.log('[omni-chat-bridge] bound');
})();
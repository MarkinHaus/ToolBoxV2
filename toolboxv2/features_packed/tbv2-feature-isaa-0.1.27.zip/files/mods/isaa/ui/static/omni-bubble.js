/**
 * omni-bubble.js — Speech Bubble Custom Element für Omni Talk Mode
 *
 * Features:
 *   - 4 vertikale Balken in einem Oval, animiert pro State
 *   - Farben: idle=grau, recording=grün, thinking=lila, speaking=blau, error=rot
 *   - Click-Logik: idle→recording (start), recording→thinking (stop),
 *                  speaking→idle (barge-in)
 *   - AudioWorklet für Mic-Capture (kein Main-Thread-Block)
 *   - Web Audio API + Ring-Buffer für gapless Playback
 *   - Tooltip zeigt aktuellen State in DE
 *
 * States (gespiegelt aus omni_bridge.PHASE_TO_STATE):
 *   idle | connecting | recording | thinking | speaking | error
 *
 * WebSocket-Protokoll (muxed binary + JSON):
 *   Client -> Server:
 *     [binary]               PCM int16 LE mono (16kHz, 80ms frames via worklet)
 *     {op:"interrupt"}       Barge-in
 *     {op:"ping"}            Heartbeat
 *   Server -> Client:
 *     {type:"phase", phase:"...", omni_phase:"...", meta:{...}}
 *     {type:"transcription", text:"..."}
 *     {type:"audio_meta", text:"...", chunk_index:N}
 *     {type:"error", message:"..."}
 *     {type:"pong"}
 *     [binary]               WAV chunk (24kHz PCM)
 */
(function () {
  'use strict';

  const SAMPLE_RATE = 16000;
  const RECONNECT_INITIAL = 1000;
  const RECONNECT_MAX = 15000;
  const PING_INTERVAL = 20000;

  const TOOLTIPS = {
    idle:        'Klicken zum Sprechen',
    connecting:  'Verbinde…',
    recording:   'Aufnahme läuft — Klicken zum Stop',
    thinking:    'ISAA denkt nach…',
    speaking:    'ISAA spricht — Klicken zum Unterbrechen',
    error:       'Verbindung verloren — Klicken zum Neuverbinden',
  };

  class OmniBubble extends HTMLElement {
    constructor() {
      super();
      this.ws = null;
      this.audioCtx = null;
      this.micStream = null;
      this.audioWorklet = null;
      this.playbackGain = null;
      this.nextPlayTime = 0;
      this.state = 'idle';
      this.lastRms = 0;
      this.bars = [];
      this.bubble = null;
      this.tooltip = null;
      this.reconnectDelay = RECONNECT_INITIAL;
      this.reconnectTimer = null;
      this.pingTimer = null;
      this.userStopped = false;  // clicked to stop recording
    }

    connectedCallback() {
      this._render();
      this._bindClick();
      // Auto-connect unless user explicitly stopped us
      if (!this.userStopped) {
        this._setState('connecting');
        this._connect();
      }
    }

    disconnectedCallback() {
      this._teardown();
    }

    // -- DOM --
    _render() {
      this.innerHTML = `
        <div class="bubble state-idle" tabindex="0" role="button"
             aria-label="Omni Talk" title="Omni Talk Mode">
          <div class="bars">
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
          </div>
        </div>
        <div class="tooltip">${TOOLTIPS.idle}</div>
      `;
      this.bubble = this.querySelector('.bubble');
      this.tooltip = this.querySelector('.tooltip');
      this.bars = Array.from(this.querySelectorAll('.bar'));
    }

    _bindClick() {
      this.bubble.addEventListener('click', () => this._handleClick());
      this.bubble.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          this._handleClick();
        }
      });
    }

    // -- state machine --
    _setState(newState, meta) {
      meta = meta || {};
      const old = this.state;
      this.state = newState;

      // Update bubble class (drives all CSS animations)
      this.bubble.className = 'bubble state-' + newState;

      // Tooltip
      let tip = TOOLTIPS[newState] || '';
      if (newState === 'thinking' && meta.name) tip = `Tool: ${meta.name}…`;
      else if (newState === 'recording' && meta.speaker) tip = `Sprecher: ${meta.speaker}`;
      this.tooltip.textContent = tip;

      // Mic gating
      if (newState === 'recording') {
        this._startMicCapture();
      } else {
        this._stopMicCapture();
      }

      // AudioContext resume on first interaction
      if (this.audioCtx && this.audioCtx.state === 'suspended') {
        this.audioCtx.resume().catch(() => {});
      }

      // Dispatch global event for chat.js to optionally show transcriptions
      window.dispatchEvent(new CustomEvent('omni-state-change', {
        detail: { state: newState, meta, old }
      }));
    }

    // -- click logic --
    async _handleClick() {
      switch (this.state) {
        case 'idle':
          this._setState('recording');
          break;
        case 'connecting':
          // ignore
          break;
        case 'recording':
          this.userStopped = true;
          this._setState('thinking');
          // Recording stops automatically because the frontend stops sending PCM.
          break;
        case 'thinking':
          // no-op (wait for model)
          break;
        case 'speaking':
          // barge-in
          this._sendJson({ op: 'interrupt' });
          this._setState('idle');
          break;
        case 'error':
          this.userStopped = false;
          this._setState('connecting');
          this._connect();
          break;
      }
    }

    // -- WebSocket --
    _connect() {
      try {
        const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
        const url = `${proto}//${location.host}/ws/omni`;
        this.ws = new WebSocket(url);
        this.ws.binaryType = 'arraybuffer';
      } catch (e) {
        console.warn('[omni-bubble] WS open failed', e);
        this._setState('error');
        this._scheduleReconnect();
        return;
      }

      this.ws.onopen = () => {
        console.log('[omni-bubble] connected');
        this.reconnectDelay = RECONNECT_INITIAL;
        this._initAudio().catch((e) => console.warn('[omni-bubble] audio init', e));
        this._setState('idle');
        this._startPing();
      };

      this.ws.onmessage = (e) => this._onMessage(e);

      this.ws.onerror = () => { /* handled in onclose */ };

      this.ws.onclose = () => {
        console.log('[omni-bubble] disconnected');
        this._stopPing();
        this._stopMicCapture();
        if (!this.userStopped) {
          this._setState('error');
          this._scheduleReconnect();
        }
      };
    }

    _scheduleReconnect() {
      if (this.reconnectTimer) return;
      this.reconnectTimer = setTimeout(() => {
        this.reconnectTimer = null;
        this.reconnectDelay = Math.min(this.reconnectDelay * 2, RECONNECT_MAX);
        this._setState('connecting');
        this._connect();
      }, this.reconnectDelay);
    }

    _startPing() {
      this._stopPing();
      this.pingTimer = setInterval(() => {
        if (this.ws && this.ws.readyState === 1) this._sendJson({ op: 'ping' });
      }, PING_INTERVAL);
    }
    _stopPing() {
      if (this.pingTimer) { clearInterval(this.pingTimer); this.pingTimer = null; }
    }

    _sendJson(obj) {
      if (!this.ws || this.ws.readyState !== 1) return false;
      try { this.ws.send(JSON.stringify(obj)); return true; }
      catch (e) { return false; }
    }

    _onMessage(e) {
      if (e.data instanceof ArrayBuffer) {
        this._playAudioChunk(e.data);
        return;
      }
      let msg;
      try { msg = JSON.parse(e.data); } catch (_) { return; }

      if (msg.type === 'phase') {
        this._setState(msg.phase, msg.meta || {});
      } else if (msg.type === 'transcription') {
        // Forward to chat UI (chat.js can listen)
        window.dispatchEvent(new CustomEvent('omni-transcript', {
         detail: { text: msg.text, isAgent: msg.src === 'output', src: msg.src || 'input' }
        }));
      } else if (msg.type === 'audio_meta') {
        // Optional: show agent text in chat stream
        if (msg.text) {
          window.dispatchEvent(new CustomEvent('omni-transcript', {
            detail: { text: msg.text, isAgent: true }
          }));
        }
      } else if (msg.type === 'error') {
        console.error('[omni-bubble] server error:', msg.message);
        this._setState('error');
      } else if (msg.type === 'pong') {
        // heartbeat
      }
    }

    // -- Audio capture --
    async _initAudio() {
      if (this.audioCtx) return;
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) throw new Error('AudioContext not supported');
      this.audioCtx = new Ctx({ sampleRate: this.audioCtx ? undefined : 48000 });

      // Load mic worklet (already loaded at /static/mic-processor.js)
      await this.audioCtx.audioWorklet.addModule('/static/mic-processor.js');

      // Playback gain (for future volume control)
      this.playbackGain = this.audioCtx.createGain();
      this.playbackGain.connect(this.audioCtx.destination);
    }

    async _startMicCapture() {
      if (this.audioWorklet) return;  // already running
      try {
        if (!this.audioCtx) await this._initAudio();
        this.micStream = await navigator.mediaDevices.getUserMedia({
          audio: {
            channelCount: 1,
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          }
        });
        const source = this.audioCtx.createMediaStreamSource(this.micStream);
        this.audioWorklet = new AudioWorkletNode(this.audioCtx, 'mic-processor');
        source.connect(this.audioWorklet);

        this.audioWorklet.port.onmessage = (e) => {
          if (!e.data) return;
          const { pcm, rms } = e.data;
          // Only stream while in 'recording' state
          if (this.state === 'recording' && this.ws && this.ws.readyState === 1) {
            this.ws.send(pcm);
          }
          // Scale bars to RMS for visual feedback
          if (rms !== undefined) this._applyRms(rms);
        };
      } catch (e) {
        console.error('[omni-bubble] mic start failed', e);
        this._setState('error');
      }
    }

    _stopMicCapture() {
      if (this.audioWorklet) {
        try { this.audioWorklet.disconnect(); } catch (_) {}
        this.audioWorklet = null;
      }
      if (this.micStream) {
        try { this.micStream.getTracks().forEach((t) => t.stop()); } catch (_) {}
        this.micStream = null;
      }
      // Reset bars
      this.lastRms = 0;
    }

    // -- Audio playback (ring-buffer gapless) --
    async _playAudioChunk(arrayBuffer) {
      if (!this.audioCtx) return;
      try {
        // Clone because decodeAudioData consumes the buffer
        const ab = arrayBuffer.slice(0);
        const audioBuffer = await this.audioCtx.decodeAudioData(ab);
        const source = this.audioCtx.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(this.playbackGain);
        const now = this.audioCtx.currentTime;
        const startAt = Math.max(now, this.nextPlayTime);
        source.start(startAt);
        this.nextPlayTime = startAt + audioBuffer.duration;
        // Drive 'speaking' state on first chunk of a turn
        if (this.state !== 'speaking') this._setState('speaking');
        source.onended = () => {
          // If no more audio queued within 200ms, return to idle
          if (this.audioCtx.currentTime >= this.nextPlayTime - 0.05) {
            if (this.state === 'speaking') this._setState('idle');
          }
        };
      } catch (e) {
        console.warn('[omni-bubble] decode/play failed', e);
      }
    }

    // -- RMS -> bar heights (visual feedback while recording) --
    _applyRms(rms) {
      // Smoothed RMS in 0..1 range; amplify modestly
      const v = Math.min(1, rms * 4);
      this.lastRms = this.lastRms * 0.5 + v * 0.5;
      if (this.state !== 'recording') return;
      const baseH = 6;
      const maxH = 22;
      // Cascade 4 bars with slight offset for wave look
      const offsets = [0.0, 0.15, 0.3, 0.45];
      for (let i = 0; i < this.bars.length; i++) {
        const h = baseH + (maxH - baseH) * Math.max(0.1, this.lastRms - offsets[i] * 0.4);
        this.bars[i].style.height = h + 'px';
      }
    }

    // -- teardown --
    _teardown() {
      this._stopPing();
      if (this.reconnectTimer) { clearTimeout(this.reconnectTimer); this.reconnectTimer = null; }
      this._stopMicCapture();
      if (this.ws) {
        try { this.ws.close(); } catch (_) {}
        this.ws = null;
      }
      if (this.audioCtx) {
        try { this.audioCtx.close(); } catch (_) {}
        this.audioCtx = null;
      }
    }
  }

  customElements.define('omni-bubble', OmniBubble);

  // Expose for app.js (it can manually mount if needed)
  window.ISAA = window.ISAA || {};
  window.ISAA.OmniBubble = OmniBubble;
})();

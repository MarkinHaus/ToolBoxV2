/**
 * mic-processor.js — AudioWorklet Processor für Omni Talk Mode
 *
 * Läuft im AudioWorklet-Thread (kein Main-Thread-Blocking).
 * Konvertiert Float32 (Browser Mic, typisch 48kHz) → Int16 PCM.
 * Sendet Int16-Buffer + RMS-Lautstärke an den Main-Thread.
 *
 * Wire format (postMessage):
 *   { pcm: Int16Array.buffer, rms: float }
 *   pcm ist übertragbar (transferable) für zero-copy.
 *
 * Integration:
 *   await audioCtx.audioWorklet.addModule('/static/mic-processor.js');
 *   const node = new AudioWorkletNode(audioCtx, 'mic-processor');
 *   node.port.onmessage = (e) => { ws.send(e.data.pcm); };
 */
class MicProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this._active = true;
  }

  process(inputs, outputs, parameters) {
    if (!this._active) return false;

    const input = inputs[0];
    if (!input || !input[0] || input[0].length === 0) return true;

    const float32 = input[0];
    const len = float32.length;

    // Float32 [-1, 1] → Int16 [-32768, 32767]
    const int16 = new Int16Array(len);
    let sumSq = 0;
    for (let i = 0; i < len; i++) {
      const s = Math.max(-1, Math.min(1, float32[i]));
      int16[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
      sumSq += s * s;
    }

    // RMS für Visualisierung (Lautstärke-Balken)
    const rms = Math.sqrt(sumSq / len);

    // Transfer (zero-copy) an Main-Thread
    this.port.postMessage(
      { pcm: int16.buffer, rms: rms },
      [int16.buffer]
    );

    return true; // keep worklet alive
  }
}

registerProcessor('mic-processor', MicProcessor);
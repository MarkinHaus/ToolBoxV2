"""
Skills System - Learned behavioral patterns for FlowAgent

Replaces the overengineered RuleSet with a simpler, more effective system.

Features:
- Skill learning from successful runs (Auto + Confidence Threshold)
- Hybrid matching (Keyword first, Embedding fallback via mem.get_embeddings)
- Confidence-based activation
- Tool relevance scoring (Keyword Overlap)
- Skill sharing between agents (Explicit)
- ToolGroups migration from rule_set.py

Author: FlowAgent V3
"""

import json
import logging
import uuid
import numpy as np
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional, Any, Dict, Tuple, Callable

_log = logging.getLogger("isaa.skills")

"""
Anthropic Skill Format - Import/Export für SkillsManager

Ermöglicht das Laden und Speichern von Skills im Anthropic-kompatiblen Format:

  skills/
  ├── skill-name/
  │   ├── SKILL.md          (required: YAML frontmatter + Markdown body)
  │   ├── scripts/          (optional: executable Python/Bash scripts)
  │   ├── references/       (optional: reference docs loaded on demand)
  │   └── assets/           (optional: templates, images, fonts)
  └── other-skill/
      └── ...

SKILL.md Format:
---
name: skill-name
description: Was der Skill tut und wann er getriggert wird
license: Optional license info
---

# Skill Title

Markdown instructions here...

Author: FlowAgent V3
"""

import os
import re
import yaml
import shutil
import zipfile
from pathlib import Path
from datetime import datetime
from typing import List, Optional, Dict, Tuple, Any
from dataclasses import dataclass


# Import from your existing skills module
# from toolboxv2.mods.isaa.base.Agent.skills import Skill, SkillsManager

@dataclass
class AnthropicSkillMetadata:
    """Parsed metadata from SKILL.md frontmatter"""
    name: str
    description: str
    license: Optional[str] = None
    compatibility: Optional[str] = None
    allowed_tools: Optional[List[str]] = None
    metadata: Optional[Dict[str, Any]] = None


class SkillIOAnthropicFormat:
    """
    Import/Export Skills im Anthropic-kompatiblen Format.

    Kann als Mixin oder Extension für SkillsManager verwendet werden.
    """

    # Mapping: Anthropic source → internal source
    SOURCE_MAPPING = {
        "anthropic": "imported",
        "learned": "learned",
        "predefined": "predefined"
    }

    def __init__(self, skills_manager: 'SkillsManager'):
        """
        Args:
            skills_manager: Referenz auf den SkillsManager
        """
        self.manager = skills_manager

    # =========================================================================
    # SKILL.md PARSING
    # =========================================================================

    def parse_skill_md(self, skill_md_path: Path) -> Tuple[Optional[AnthropicSkillMetadata], Optional[str]]:
        """
        Parse SKILL.md file into metadata and body.

        Returns:
            Tuple of (metadata, body) or (None, None) on error
        """
        try:
            content = skill_md_path.read_text(encoding='utf-8')
        except Exception as e:
            _log.debug(f"[SkillIO] Failed to read {skill_md_path}: {e}")
            return None, None

        # Check for YAML frontmatter
        if not content.startswith('---'):
            _log.debug(f"[SkillIO] No YAML frontmatter in {skill_md_path}")
            return None, None

        # Extract frontmatter
        match = re.match(r'^---\n(.*?)\n---\n?(.*)', content, re.DOTALL)
        if not match:
            _log.debug(f"[SkillIO] Invalid frontmatter format in {skill_md_path}")
            return None, None

        frontmatter_text = match.group(1)
        body = match.group(2).strip()

        # Parse YAML
        try:
            fm = yaml.safe_load(frontmatter_text)
            if not isinstance(fm, dict):
                _log.debug(f"[SkillIO] Frontmatter must be a dict in {skill_md_path}")
                return None, None
        except yaml.YAMLError as e:
            _log.debug(f"[SkillIO] YAML parse error in {skill_md_path}: {e}")
            return None, None

        # Validate required fields
        if 'name' not in fm or 'description' not in fm:
            _log.debug(f"[SkillIO] Missing name or description in {skill_md_path}")
            return None, None

        metadata = AnthropicSkillMetadata(
            name=fm['name'],
            description=fm['description'],
            license=fm.get('license'),
            compatibility=fm.get('compatibility'),
            allowed_tools=fm.get('allowed-tools'),
            metadata=fm.get('metadata')
        )

        return metadata, body

    # =========================================================================
    # IMPORT: Directory → SkillsManager
    # =========================================================================

    def import_skills_from_directory(
        self,
        skills_dir: Path,
        overwrite: bool = False,
        source_tag: str = "imported"
    ) -> Dict[str, bool]:
        """
        Import all skills from a directory structure.

        Args:
            skills_dir: Path to skills directory containing skill folders
            overwrite: Whether to overwrite existing skills
            source_tag: Source tag for imported skills

        Returns:
            Dict mapping skill_name → success
        """
        skills_dir = Path(skills_dir)
        results = {}

        if not skills_dir.exists():
            _log.debug(f"[SkillIO] Directory not found: {skills_dir}")
            return results

        # Iterate through subdirectories
        for item in skills_dir.iterdir():
            if not item.is_dir():
                continue

            skill_md = item / "SKILL.md"
            if not skill_md.exists():
                continue

            success = self.import_single_skill(item, overwrite, source_tag)
            results[item.name] = success

        imported = sum(1 for v in results.values() if v)
        _log.debug(f"[SkillIO] Imported {imported}/{len(results)} skills from {skills_dir}")

        return results

    def import_single_skill(
        self,
        skill_dir: Path,
        overwrite: bool = False,
        source_tag: str = "imported"
    ) -> bool:
        """
        Import a single skill from its directory.

        Args:
            skill_dir: Path to skill directory (contains SKILL.md)
            overwrite: Whether to overwrite if exists
            source_tag: Source tag

        Returns:
            True if successful
        """
        skill_dir = Path(skill_dir)
        skill_md_path = skill_dir / "SKILL.md"

        if not skill_md_path.exists():
            _log.debug(f"[SkillIO] SKILL.md not found in {skill_dir}")
            return False

        # Parse SKILL.md
        metadata, body = self.parse_skill_md(skill_md_path)
        if not metadata:
            return False

        # Generate skill ID from name
        skill_id = self._generate_skill_id(metadata.name)

        # Check if exists
        if skill_id in self.manager.skills and not overwrite:
            _log.debug(f"[SkillIO] Skill already exists: {skill_id} (use overwrite=True)")
            return False

        # Extract triggers from description (simple heuristic)
        triggers = self._extract_triggers(metadata.name, metadata.description)

        # Load allowed tools if specified
        tools_used = metadata.allowed_tools or []

        # Check for scripts directory → add tool hints
        scripts_dir = skill_dir / "scripts"
        if scripts_dir.exists():
            for script in scripts_dir.glob("*.py"):
                tools_used.append(f"script:{script.stem}")

        # Create Skill object
        # NOTE: Import Skill from your module
        from toolboxv2.mods.isaa.base.Agent.skills import Skill

        skill = Skill(
            id=skill_id,
            name=metadata.name,
            triggers=triggers,
            instruction=body,
            tools_used=tools_used,
            tool_groups=[],
            source=source_tag,
            confidence=0.8 if source_tag == "imported" else 0.65,  # Imported skills start higher
            activation_threshold=0.6
        )

        # Store additional metadata
        skill._anthropic_metadata = {
            'license': metadata.license,
            'compatibility': metadata.compatibility,
            'skill_dir': str(skill_dir),
            'has_scripts': scripts_dir.exists(),
            'has_references': (skill_dir / "references").exists(),
            'has_assets': (skill_dir / "assets").exists()
        }

        self.manager.skills[skill_id] = skill
        self.manager._skill_embeddings_dirty = True

        _log.debug(f"[SkillIO] Imported skill: {metadata.name} → {skill_id}")
        return True

    def import_from_skill_file(
        self,
        skill_file: Path,
        extract_dir: Optional[Path] = None,
        overwrite: bool = False
    ) -> bool:
        """
        Import from .skill file (ZIP format).

        Args:
            skill_file: Path to .skill file
            extract_dir: Where to extract (temp if None)
            overwrite: Whether to overwrite

        Returns:
            True if successful
        """
        skill_file = Path(skill_file)

        if not skill_file.exists():
            _log.debug(f"[SkillIO] File not found: {skill_file}")
            return False

        if extract_dir is None:
            extract_dir = Path("/tmp") / f"skill_extract_{skill_file.stem}"

        extract_dir = Path(extract_dir)

        try:
            # Extract ZIP
            with zipfile.ZipFile(skill_file, 'r') as zf:
                zf.extractall(extract_dir)

            # Find skill directory (should be top-level folder in ZIP)
            skill_dirs = [d for d in extract_dir.iterdir() if d.is_dir() and (d / "SKILL.md").exists()]

            if not skill_dirs:
                _log.debug(f"[SkillIO] No valid skill found in {skill_file}")
                return False

            # Import first skill found
            return self.import_single_skill(skill_dirs[0], overwrite)

        except zipfile.BadZipFile:
            _log.debug(f"[SkillIO] Invalid ZIP file: {skill_file}")
            return False
        except Exception as e:
            _log.debug(f"[SkillIO] Error importing {skill_file}: {e}")
            return False

    # =========================================================================
    # EXPORT: SkillsManager → Directory
    # =========================================================================

    def export_skills_to_directory(
        self,
        output_dir: Path,
        skill_ids: Optional[List[str]] = None,
        include_predefined: bool = False
    ) -> Dict[str, bool]:
        """
        Export skills to Anthropic-compatible directory structure.

        Args:
            output_dir: Output directory
            skill_ids: Specific skill IDs to export (None = all learned/imported)
            include_predefined: Whether to include predefined skills

        Returns:
            Dict mapping skill_id → success
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        results = {}

        # Select skills to export
        if skill_ids:
            skills_to_export = [self.manager.skills[sid] for sid in skill_ids if sid in self.manager.skills]
        else:
            skills_to_export = [
                s for s in self.manager.skills.values()
                if s.source != "predefined" or include_predefined
            ]

        for skill in skills_to_export:
            success = self.export_single_skill(skill, output_dir)
            results[skill.id] = success

        exported = sum(1 for v in results.values() if v)
        _log.debug(f"[SkillIO] Exported {exported}/{len(results)} skills to {output_dir}")

        return results

    def export_single_skill(self, skill: 'Skill', output_dir: Path) -> bool:
        """
        Export a single skill to Anthropic format.

        Args:
            skill: Skill object to export
            output_dir: Parent directory for skill folder

        Returns:
            True if successful
        """
        # Convert skill name to kebab-case for directory
        dir_name = self._to_kebab_case(skill.name)
        skill_dir = Path(output_dir) / dir_name

        try:
            skill_dir.mkdir(parents=True, exist_ok=True)

            # Build SKILL.md content
            skill_md_content = self._build_skill_md(skill)

            # Write SKILL.md
            skill_md_path = skill_dir / "SKILL.md"
            skill_md_path.write_text(skill_md_content, encoding='utf-8')

            # Create empty resource directories if skill had them
            if hasattr(skill, '_anthropic_metadata'):
                meta = skill._anthropic_metadata
                if meta.get('has_scripts'):
                    (skill_dir / "scripts").mkdir(exist_ok=True)
                if meta.get('has_references'):
                    (skill_dir / "references").mkdir(exist_ok=True)
                if meta.get('has_assets'):
                    (skill_dir / "assets").mkdir(exist_ok=True)

            _log.debug(f"[SkillIO] Exported: {skill.name} → {skill_dir}")
            return True

        except Exception as e:
            _log.debug(f"[SkillIO] Failed to export {skill.name}: {e}")
            return False

    def export_to_skill_file(
        self,
        skill_id: str,
        output_path: Optional[Path] = None
    ) -> Optional[Path]:
        """
        Export skill to .skill file (ZIP format).

        Args:
            skill_id: ID of skill to export
            output_path: Output path for .skill file

        Returns:
            Path to created .skill file or None
        """
        if skill_id not in self.manager.skills:
            _log.debug(f"[SkillIO] Skill not found: {skill_id}")
            return None

        skill = self.manager.skills[skill_id]
        dir_name = self._to_kebab_case(skill.name)

        # Create temp directory for skill
        temp_dir = Path("/tmp") / f"skill_export_{dir_name}"
        temp_dir.mkdir(parents=True, exist_ok=True)

        # Export to temp directory
        if not self.export_single_skill(skill, temp_dir):
            return None

        skill_dir = temp_dir / dir_name

        # Determine output path
        if output_path is None:
            output_path = Path.cwd() / f"{dir_name}.skill"
        else:
            output_path = Path(output_path)

        try:
            # Create ZIP
            with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                for file_path in skill_dir.rglob('*'):
                    if file_path.is_file():
                        arcname = file_path.relative_to(temp_dir)
                        zf.write(file_path, arcname)

            _log.debug(f"[SkillIO] Created: {output_path}")
            return output_path

        except Exception as e:
            _log.debug(f"[SkillIO] Failed to create .skill file: {e}")
            return None
        finally:
            # Cleanup temp
            shutil.rmtree(temp_dir, ignore_errors=True)

    # =========================================================================
    # HELPERS
    # =========================================================================

    def _generate_skill_id(self, name: str) -> str:
        """Generate skill ID from name"""
        # Convert to snake_case
        normalized = name.lower().replace('-', '_').replace(' ', '_')
        normalized = ''.join(c for c in normalized if c.isalnum() or c == '_')
        return f"imported_{normalized[:30]}"

    def _to_kebab_case(self, name: str) -> str:
        """Convert name to kebab-case for directory"""
        # Replace spaces and underscores with hyphens
        kebab = name.lower().replace(' ', '-').replace('_', '-')
        # Remove invalid characters
        kebab = ''.join(c for c in kebab if c.isalnum() or c == '-')
        # Remove consecutive hyphens
        while '--' in kebab:
            kebab = kebab.replace('--', '-')
        return kebab.strip('-')[:64]

    def _extract_triggers(self, name: str, description: str) -> List[str]:
        """Extract trigger keywords from name and description"""
        triggers = []

        # Add words from name
        name_words = name.lower().replace('-', ' ').split()
        triggers.extend(name_words)

        # Extract key phrases from description
        # Look for patterns like "when ... for ...", "use for ...", etc.
        desc_lower = description.lower()

        # Common trigger patterns
        patterns = [
            r'when\s+(?:the\s+)?user\s+(?:asks?\s+)?(?:to\s+|for\s+)?([^,.]+)',
            r'use\s+(?:this\s+)?(?:skill\s+)?(?:to|for|when)\s+([^,.]+)',
            r'for\s+([^,.]+(?:files?|documents?|tasks?))',
        ]

        for pattern in patterns:
            matches = re.findall(pattern, desc_lower)
            for match in matches:
                words = match.split()[:3]  # Take first 3 words
                triggers.extend(words)

        # Remove duplicates and common words
        stop_words = {'the', 'a', 'an', 'to', 'for', 'with', 'and', 'or', 'is', 'are'}
        triggers = list(dict.fromkeys(t for t in triggers if t not in stop_words and len(t) > 2))

        return triggers[:10]  # Limit to 10 triggers

    def _build_skill_md(self, skill: 'Skill') -> str:
        """Build SKILL.md content from Skill object"""
        # Build YAML frontmatter
        frontmatter = {
            'name': self._to_kebab_case(skill.name),
            'description': self._build_description(skill)
        }

        # Add license if available
        if hasattr(skill, '_anthropic_metadata') and skill._anthropic_metadata.get('license'):
            frontmatter['license'] = skill._anthropic_metadata['license']

        # Build body
        body_lines = [
            f"# {skill.name}",
            "",
            "## Overview",
            "",
            f"**Source:** {skill.source}",
            f"**Confidence:** {skill.confidence:.2f}",
            f"**Success Rate:** {skill.success_count}/{skill.success_count + skill.failure_count}",
            "",
            "## Instructions",
            "",
            skill.instruction,
            "",
        ]

        # Add tools section if any
        if skill.tools_used:
            body_lines.extend([
                "## Tools Used",
                "",
                *[f"- `{tool}`" for tool in skill.tools_used],
                ""
            ])

        # Add triggers section
        if skill.triggers:
            body_lines.extend([
                "## Triggers",
                "",
                f"Keywords: {', '.join(skill.triggers)}",
                ""
            ])

        # Combine
        yaml_str = yaml.dump(frontmatter, default_flow_style=False, allow_unicode=True)

        return f"---\n{yaml_str}---\n\n" + '\n'.join(body_lines)

    def _build_description(self, skill: 'Skill') -> str:
        """Build description from skill for frontmatter"""
        # Combine instruction preview with triggers
        instruction_preview = skill.instruction[:200].replace('\n', ' ')
        triggers_str = ', '.join(skill.triggers[:5])

        desc = f"{instruction_preview}... Use when: {triggers_str}"
        return desc[:1024]  # Max length per spec


# =============================================================================
# CONVENIENCE: Direct integration
# =============================================================================
import os, json, tempfile, urllib.request
from pathlib import Path
from urllib.parse import urlparse, unquote


def _gh_headers():
    h = {"User-Agent": "ToolBoxV2-skills", "Accept": "application/vnd.github+json"}
    tok = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
    if tok:
        h["Authorization"] = f"Bearer {tok}"
    return h


def _http_get(url, headers=None):
    req = urllib.request.Request(url, headers=headers or {})
    with urllib.request.urlopen(req, timeout=30) as r:
        return r.read()


def _parse_github_url(url):
    """-> (owner, repo, ref|None, subpath) for github.com (tree/blob) or raw URLs."""
    p = urlparse(url)
    host = p.netloc.lower()
    parts = [unquote(x) for x in p.path.strip("/").split("/") if x]
    if host == "github.com" and len(parts) >= 2:
        owner, repo = parts[0], parts[1]
        if len(parts) <= 2:                       # repo root, default branch
            return owner, repo, None, ""
        ref = parts[3] if len(parts) > 3 else None  # parts[2] = tree|blob
        return owner, repo, ref, "/".join(parts[4:])
    if host in ("raw.githubusercontent.com", "raw.github.com") and len(parts) >= 3:
        owner, repo, rest = parts[0], parts[1], parts[2:]
        if len(rest) >= 2 and rest[0] == "refs" and rest[1] in ("heads", "tags"):
            ref, sub = (rest[2] if len(rest) > 2 else None), "/".join(rest[3:])
        else:
            ref, sub = rest[0], "/".join(rest[1:])
        return owner, repo, ref, sub
    raise ValueError(f"Unsupported skill URL: {url}")


def _gh_contents(owner, repo, ref, sub):
    api = f"https://api.github.com/repos/{owner}/{repo}/contents/{sub.strip('/')}"
    if ref:
        api += f"?ref={ref}"
    return json.loads(_http_get(api, _gh_headers()).decode("utf-8"))


def _download_dir(owner, repo, ref, listing, dest: Path):
    dest.mkdir(parents=True, exist_ok=True)
    for e in listing:
        target = dest / e["name"]
        if e["type"] == "dir":
            _download_dir(owner, repo, ref, _gh_contents(owner, repo, ref, e["path"]), target)
        else:
            target.write_bytes(_http_get(e["download_url"]))


def _resolve_remote_skill(url) -> Path:
    owner, repo, ref, sub = _parse_github_url(url)
    meta = _gh_contents(owner, repo, ref, sub)          # dict=file, list=dir
    tmp = Path(tempfile.mkdtemp(prefix="tb_skill_"))
    if isinstance(meta, dict):                           # single file (.skill / SKILL.md)
        out = tmp / meta["name"]
        out.write_bytes(_http_get(meta["download_url"]))
        return out
    out = tmp / (sub.rsplit("/", 1)[-1] or repo)        # directory
    _download_dir(owner, repo, ref, meta, out)
    return out




def add_anthropic_skill_io(skills_manager: 'SkillsManager'):
    """
    Add Anthropic skill IO methods to an existing SkillsManager instance.

    Usage:
        from skill_io_anthropic import add_anthropic_skill_io

        manager = SkillsManager("agent1")
        add_anthropic_skill_io(manager)

        # Now you can use:
        manager.import_skills("/path/to/skills")
        manager.export_skills("/path/to/output")
    """
    io = SkillIOAnthropicFormat(skills_manager)

    def import_skills(path, overwrite=False):
        if str(path).startswith(("http://", "https://")):
            path = _resolve_remote_skill(str(path))
        path = Path(path)
        if str(path).endswith(".skill"):
            return io.import_from_skill_file(path, overwrite=overwrite)
        if not (path / "SKILL.md").exists():
            return io.import_skills_from_directory(path, overwrite=overwrite)
        return {path.name: io.import_single_skill(path, overwrite=overwrite)}

    skills_manager._skill_io = io
    skills_manager.import_skills =import_skills
    """ lambda path, overwrite=False: (
        io.import_from_skill_file(Path(path), overwrite=overwrite)
        if str(path).endswith('.skill')
        else io.import_skills_from_directory(Path(path), overwrite=overwrite)
        if not (Path(path) / "SKILL.md").exists()
        else {Path(path).name: io.import_single_skill(Path(path), overwrite=overwrite)}
    )"""
    skills_manager.export_skills = io.export_skills_to_directory
    skills_manager.export_skill_file = io.export_to_skill_file

    return skills_manager

# =============================================================================
# DATA STRUCTURES
# =============================================================================

@dataclass
class Skill:
    """
    Learned or predefined behavioral pattern.

    Core concept: Verbally tell the model HOW to do things,
    learned from successful runs or predefined for common patterns.
    """
    id: str
    name: str
    triggers: List[str]  # Keywords für Matching
    instruction: str  # Nummerierte Anleitung (das Herzstück)

    description: str = field(default="")

    # Tool Context
    tools_used: List[str] = field(default_factory=list)
    tool_groups: List[str] = field(default_factory=list)

    # Learning Metadata
    source: str = "predefined"  # "predefined" | "learned" | "imported"
    confidence: float = 1.0  # 0.0-1.0
    activation_threshold: float = 0.6  # Wird erst aktiv wenn confidence >= threshold
    success_count: int = 0
    failure_count: int = 0
    total_uses: int = 0

    # Timestamps
    created_at: datetime = field(default_factory=datetime.now)
    last_used: Optional[datetime] = None


    recent_queries: list = field(default_factory=list)
    _recent_queries_max: int = field(default=15, repr=False, compare=False)

    def is_active(self) -> bool:
        """Skill ist aktiv wenn confidence >= threshold"""
        return self.confidence >= self.activation_threshold

    def matches_keywords(self, query: str) -> bool:
        """Keyword-basiertes Matching"""
        query_lower = query.lower()
        return any(trigger.lower() in query_lower for trigger in self.triggers)

    def record_usage(
        self,
        success: bool,
        query: str = "",
        trigger_keyword: str = "",
        iterations_used: int = 0,
    ) -> None:
        """Lernen aus Verwendung + Query-Log."""
        now = datetime.now()
        self.last_used = now
        self.total_uses += 1

        if success:
            self.success_count += 1
            self.confidence = min(1.0, self.confidence + 0.1)
        else:
            self.failure_count += 1
            self.confidence = max(0.1, self.confidence - 0.15)

        # Kompaktes Log-Entry
        entry = {
            "ts": now.isoformat(timespec="seconds"),
            "q": query[:100],
            "kw": trigger_keyword,
            "ok": success,
            "iters": iterations_used,
        }
        self.recent_queries.append(entry)
        if len(self.recent_queries) > self._recent_queries_max:
            self.recent_queries.pop(0)

    @property
    def effectiveness(self) -> float:
        """0.0-1.0: success_count / total_uses."""
        return self.success_count / self.total_uses if self.total_uses else 0.0

    @property
    def avg_iterations(self) -> float:
        """Durchschnittliche Iterations-Nutzung über alle geloggten Queries."""
        logged = [e["iters"] for e in self.recent_queries if e.get("iters")]
        return sum(logged) / len(logged) if logged else 0.0

    async def merge_with(self, other: 'Skill'):
        """
        Merge another skill's data into this one.
        Used when a similar skill is detected during learning.
        """
        # Merge triggers (unique)
        existing_triggers = set(t.lower() for t in self.triggers)
        for trigger in other.triggers:
            if trigger.lower() not in existing_triggers:
                self.triggers.append(trigger)
                existing_triggers.add(trigger.lower())

        # Merge tools (unique)
        existing_tools = set(self.tools_used)
        for tool in other.tools_used:
            if tool not in existing_tools:
                self.tools_used.append(tool)
                existing_tools.add(tool)

        # call blitz model to merge (unify) instruction
        # ---- Merge instructions using Blitz model ----
        sys_prompt = (
            "You are an instruction unification engine.\n"
            "Given two instructions, return a single merged instruction.\n"
            "Return ONLY the merged instruction. No explanations."
        )

        user_prompt = (
            f"Instruction A (old {self.confidence=}):\n"
            f"{self.instruction}\n\n"
            f"Instruction B (new {other.confidence}):\n"
            f"{other.instruction}\n\n"
            "Balanced Merged instruction:"
        )

        from toolboxv2.mods.isaa.extras.adapter import litellm_complete
        response = await litellm_complete(
            model=os.getenv("BLITZMODEL"),
            messages=[
                {"role": "system", "content": sys_prompt},
                {"role": "user", "content": user_prompt},
            ],
        )

        # Extract merged instruction text safely
        self.instruction = response.strip()

        self.last_used = datetime.now()

    def to_dict(self) -> dict:
        """Serialize for checkpoint"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'triggers': self.triggers,
            'instruction': self.instruction,
            'tools_used': self.tools_used,
            'tool_groups': self.tool_groups,
            'source': self.source,
            'confidence': self.confidence,
            'activation_threshold': self.activation_threshold,
            'success_count': self.success_count,
            'failure_count': self.failure_count,
            'created_at': self.created_at.isoformat(),
            'total_uses': self.total_uses,
            'recent_queries': self.recent_queries,
            'last_used': self.last_used.isoformat() if self.last_used else None
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'Skill':
        """Deserialize from checkpoint"""
        skill = cls(
            id=data['id'],
            name=data['name'],
            triggers=data['triggers'],
            instruction=data['instruction'],
            description=data.get('description', ""),
            tools_used=data.get('tools_used', []),
            tool_groups=data.get('tool_groups', []),
            source=data.get('source', 'predefined'),
            confidence=data.get('confidence', 1.0),
            activation_threshold=data.get('activation_threshold', 0.6),
            success_count=data.get('success_count', 0),
            failure_count=data.get('failure_count', 0)
        )
        if data.get('created_at'):
            skill.created_at = datetime.fromisoformat(data['created_at'])
        if data.get('last_used'):
            skill.last_used = datetime.fromisoformat(data['last_used'])
        skill.total_uses = data.get('total_uses', 0)
        skill.recent_queries = data.get('recent_queries', [])
        return skill


@dataclass
class ToolGroup:
    """
    Groups multiple tools under a single display name.
    Migrated from rule_set.py - kept because it's useful.

    Instead of showing 50 Discord tools, show "discord_tools: Discord Server APIs"
    """
    name: str  # "discord_tools"
    display_name: str  # "Discord Server APIs"
    description: str  # Short description
    tool_names: List[str]  # Actual tool names in registry
    trigger_keywords: List[str]  # ["discord", "server", "bot"]
    priority: int = 5  # Sorting priority (1=highest)
    icon: str = "🔧"
    auto_generated: bool = False

    def matches_query(self, query: str) -> bool:
        """Check if query matches this group's keywords"""
        query_lower = query.lower()
        return any(kw.lower() in query_lower for kw in self.trigger_keywords)

    def to_dict(self) -> dict:
        return {
            'name': self.name,
            'display_name': self.display_name,
            'description': self.description,
            'tool_names': self.tool_names,
            'trigger_keywords': self.trigger_keywords,
            'priority': self.priority,
            'icon': self.icon,
            'auto_generated': self.auto_generated
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'ToolGroup':
        return cls(**data)


# =============================================================================
# SKILLS MANAGER
# =============================================================================

class SkillsManager:
    """
    Manages skills for a FlowAgent instance.

    Features:
    - Hybrid matching (Keyword first, Embedding fallback)
    - Confidence-based activation
    - Tool relevance scoring (Keyword Overlap)
    - Skill sharing (Explicit)
    - ToolGroups management
    """
    _skill_io = None
    import_skills = None
    export_skills = None
    export_skill_file = None

    def __init__(self, agent_name: str, memory_instance: Any = None, anthropic_skills=None, match_embedding=False):
        """
        Initialize SkillsManager.

        Args:
            agent_name: Name of parent agent
            memory_instance: Memory instance with get_embeddings() method
        """
        self.agent_name = agent_name
        self._memory = memory_instance
        self.match_embedding = match_embedding

        # Skills Storage
        self.skills: Dict[str, Skill] = {}

        # Tool Groups (migrated from rule_set.py)
        self.tool_groups: Dict[str, ToolGroup] = {}

        # Embedding Cache for Skills (lazy loaded)
        self._skill_embeddings_dirty = True
        self._skill_embeddings_cache: Dict[str, np.ndarray] = {}

        # Initialize predefined skills
        self._init_predefined_skills()
        if anthropic_skills is not None:
            add_anthropic_skill_io(self)
            if isinstance(anthropic_skills, str):
                self.import_skills(anthropic_skills, overwrite=True)


    def _init_predefined_skills(self):
        """Initialize predefined skills focused on user management and interaction"""
        predefined = [

            # ═══════════════════════════════════════════════════════════════
            # 🟢 CLEANUP (9) — Solide Skills, SDO-Format hinzugefügt
            # ═══════════════════════════════════════════════════════════════

            # === 1. USER PREFERENCE SAVE ===
            Skill(
                id="user_preference_save",
                name="User Preference Save",
                description="Use when user expresses a preference to remember, says 'merke', 'speicher', 'vergiss nicht', or wants a setting saved for future sessions",
                triggers=[
                    "merke", "speicher", "präferenz", "preference",
                    "bevorzuge", "vergiss nicht", "einstellung speichern",
                    "mach das zum standard"
                ],
                instruction="""Für das Speichern von User Präferenzen:
        1. Identifiziere die konkrete Präferenz aus der Anfrage
        2. Formuliere sie als klares Key-Value Paar
        3. Nutze think() um die Präferenz zu strukturieren
        4. Speichere mit memory_inject oder geeignetem Tool
        5. Bestätige dem User WAS GENAU gespeichert wurde
        6. Frage nach falls die Präferenz unklar ist - rate NICHT""",
                tools_used=["think", "memory_inject", "final_answer"],
                tool_groups=["memory"],
                source="predefined"
            ),

            # === 2. CLARIFICATION NEEDED ===
            Skill(
                id="clarification_needed",
                name="Clarification Request",
                description="Use when request is ambiguous, multiple interpretations exist, or agent is uncertain about context or specific details",
                triggers=[
                    "unklar", "was meinst du", "verstehe nicht",
                    "mehr details", "genauer", "konkretisier",
                    "ich bin mir unsicher", "mehrere möglichkeiten", "welche meinst du"
                ],
                instruction="""Wenn Klarstellung nötig ist:
        1. Identifiziere WAS genau unklar ist
        2. Formuliere SPEZIFISCHE Fragen (nicht "was meinst du?")
        3. Biete Optionen an wenn möglich ("Meinst du A oder B?")
        4. Erkläre warum die Info wichtig ist
        5. Warte auf Antwort bevor du fortfährst
        6. NIEMALS raten bei wichtigen Details""",
                tools_used=["think", "final_answer"],
                tool_groups=[],
                source="predefined"
            ),

            # === 3. VFS KNOWLEDGE BASE ===
            Skill(
                id="vfs_knowledge_base",
                name="Knowledge Base Management",
                description="Use when managing structured knowledge in VFS, creating topic files in /info/, or querying persistent documentation",
                triggers=[
                    "wissen", "knowledge", "dokumentation", "docs",
                    "sammlung", "archiv", "referenz", "nachschlagen",
                    "was weiß ich über", "zeig mir alles zu", "thema"
                ],
                instruction="""Für Wissensmanagement im VFS:
        1. Struktur der Knowledge Base:
           /info/
           ├── [thema1].md
           ├── [thema2].md
           └── index.md (Übersicht aller Themen)
        2. Bei neuen Informationen:
           - Prüfe ob /info/[thema].md existiert (vfs_list)
           - Existiert: Lesen, ergänzen, schreiben
           - Neu: Erstellen mit klarer Struktur
           - index.md updaten
        3. Bei Abfragen:
           - Erst /info/ durchsuchen
           - Relevante Dateien lesen
           - Konsolidierte Antwort geben
        4. Format in .md Dateien:
           - Klare Überschriften
           - Datum der letzten Änderung
           - Quellen wenn vorhanden
        5. Regelmäßig aufräumen: Veraltetes markieren oder löschen""",
                tools_used=["think", "vfs_read", "vfs_write", "vfs_list", "vfs_mkdir", "final_answer"],
                tool_groups=["vfs"],
                source="predefined"
            ),

            # === 4. PARALLEL SUBTASKS ===
            Skill(
                id="parallel_subtasks",
                name="Parallel Sub-Task Execution",
                description="Use when tasks are independent and can run in parallel, comparing multiple sources, or gathering data simultaneously",
                triggers=[
                    "parallel", "gleichzeitig", "recherchiere mehrere",
                    "vergleiche", "sammle von verschiedenen", "und dann zusammen",
                    "gleichzeitig prüfen"
                ],
                instruction="""Für parallelisierbare Aufgaben:
        1. Identifiziere UNABHÄNGIGE Teilaufgaben (die nicht aufeinander warten)
        2. Für jede Teilaufgabe: spawn_sub_agent(task=..., output_dir=/sub/[name], wait=False)
        3. Wenn alle gestartet: wait_for([alle_ids])
        4. Lese Ergebnisse aus /sub/[name]/result.md
        5. Kombiniere/Vergleiche die Ergebnisse
        6. WICHTIG: Sub-Agents können NUR in ihren output_dir schreiben
        7. WICHTIG: Gib Sub-Agents klare, spezifische Tasks - sie können NICHT zurückfragen""",
                tools_used=["think", "spawn_sub_agent", "wait_for", "vfs_read", "final_answer"],
                tool_groups=["vfs"],
                source="predefined"
            ),

            # === 5. MASTER ORCHESTRATOR ===
            Skill(
                id="master_orchestrator",
                name="System Orchestration Protocol",
                description="Use when deciding between Coder, Chains, or Sub-Agents for implementation work, or delegating complex tasks to specialized subsystems",
                triggers=[
                    "entwickle", "bau mir", "refactor", "architektur",
                    "feature", "delegiere", "was ist der beste weg für"
                ],
                instruction="""DU BIST DER TECH-LEAD, NICHT DER PROGRAMMIERER. Schreibe NIEMALS manuell Code mit vfs_write!
        Befolge strikt diese Delegations-Hierarchie:

        1. FÜR KOMPLEXEN CODE (Features, Refactoring, Bugfixes):
           -> ZWINGEND den Coder verwenden!
           -> Ablauf: analyze_codebase() -> refine_task() -> spawn_coder() -> observe() -> validate_worktree() -> accept()

        2. FÜR WIEDERKEHRENDE AUTOMATISIERUNG (Scraping, Deployments, Reports):
           -> ZWINGEND Chains verwenden!
           -> Ablauf: list_auto_get_fitting() -> run_chain() oder create_validate_chain()

        3. FÜR PARALLELE RECHERCHE ODER DATENVERARBEITUNG:
           -> ZWINGEND Sub-Agents verwenden!
           -> Ablauf: spawn_sub_agent() für jeden Teil -> wait_for()

        4. FÜR LOKALE NOTIZEN & WISSEN:
           -> memory_save() für dauerhafte Architektur-Fakten.
           -> vfs_write() NUR für kleine Markdown-Pläne (z.B. /plan.md).

        Denke als Architekt: Plane die Lösung, delegiere die Ausführung, validiere das Ergebnis.""",
                tools_used=["think", "analyze_codebase", "refine_task", "spawn_coder", "memory_save",
                            "list_auto_get_fitting"],
                tool_groups=["coder", "automation", "memory"],
                source="predefined"
            ),

            # === 6. CODER DELEGATION SOP ===
            Skill(
                id="coder_delegation_sop",
                name="CoderAgent Delegation Workflow",
                description="Use when delegating code generation to the isolated CoderAgent environment for features, bugfixes, or refactoring",
                triggers=[
                    "coder", "lass den coder", "delegiere code", "bugfix",
                    "schreibe das script", "implementierung durch coder"
                ],
                instruction="""Workflow für Code-Generierung (Der Coder ist eine isolierte Umgebung):
        1. KONTEXT SCHAFFEN: Nutze `analyze_codebase(root=".")`, um den Baum und TODOs zu sehen.
        2. TASK BAUEN: Nutze `refine_task(task, context)`, um Risiken zu klären.
        3. WISSEN TEILEN: Nutze `memory_recall()`, um relevante Architekturentscheidungen zu finden, hänge diese Infos an den Task an.
        4. AUSFÜHREN: `spawn_coder(refined_task)`. Notiere dir die coder_id.
        5. ÜBERWACHEN: Führe regelmäßig `observe()` aus! Wenn der Coder im 'status': 'done' ist, mache weiter.
        6. QA & MERGE: Führe `validate_worktree(coder_id)` aus. Wenn 'passed': True, DANN `accept(coder_id)`. Wenn False, gib dem Coder Feedback via `interact()`.
        7. WISSEN SPEICHERN: Nach erfolgreichem `accept` speichere Zusammenfassungen der neuen Komponenten in `memory_save()`.
        NIEMALS Code blind mergen!""",
                tools_used=["analyze_codebase", "refine_task", "spawn_coder", "observe", "validate_worktree", "accept",
                            "memory_recall", "memory_save"],
                tool_groups=["coder"],
                source="predefined"
            ),

            # === 7. MEMORY INTELLIGENCE SOP ===
            Skill(
                id="memory_intelligence_sop",
                name="Deep Memory Utilization",
                description="Use when recalling stored knowledge, analyzing project context, or deciding between memory_recall and memory_analyse",
                triggers=[
                    "erinnere dich", "zusammenhang", "kontext", "verstehe nicht",
                    "analysiere projekt", "wie funktioniert", "was wissen wir über"
                ],
                instruction="""Nutzung des Langzeitgedächtnisses:

        1. EINFACHE SUCHE (`memory_recall`):
           - Nutze dies ZUERST. Es ist schnell und kostengünstig.
           - Gut für: Konkrete Fragen, Dateipfade, Tech-Stack Infos.

        2. TIEFE ANALYSE (`memory_analyse`):
           - Nutze dies, wenn `memory_recall` keine guten Ergebnisse liefert oder das Thema komplex ist.
           - Der Memory-Actor führt selbstständig mehrere Schritte aus (Suche -> Graph-Traversal -> Summarization).
           - Gut für: "Fasse das Projekt zusammen", "Wie interagieren Modul A und B?", "Gibt es widersprüchliche Infos?".

        3. SPEICHERN (`memory_save`):
           - Speichere nur 'Ewige Wahrheiten' und Architektur-Entscheidungen.
           - Speichere KEINE temporären Chat-Inhalte (passiert automatisch).
           - Nutze 'concepts' tags für bessere Auffindbarkeit.""",
                tools_used=["memory_recall", "memory_analyse", "memory_save"],
                tool_groups=["memory"],
                source="predefined"
            ),

            # === 8. CHAIN AUTOMATION SOP ===
            Skill(
                id="chain_automation_sop",
                name="Workflow Automation via Chains",
                description="Use when automating recurring workflows via Chains, or checking if a Chain exists for a standard process",
                triggers=[
                    "prozess", "ablauf", "kette", "chain",
                    "standard operating procedure", "automatisierung"
                ],
                instruction="""Richtlinien für Chains (SOPs):
        1. DISCOVERY: Bevor du eine Standard-Aufgabe manuell in 10 LLM-Loops löst, nutze `list_auto_get_fitting("beschreibung")`, um zu sehen, ob eine Chain existiert.
        2. EXECUTION: Wenn eine 'VALID' Chain existiert, nutze `run_chain(chain_id, input_data)`.
        3. CREATION: Wenn ein komplexer Prozess immer wieder gebraucht wird (z.B. "Webseite scrapen, bereinigen, in DB speichern"):
           - Erstelle EINE deterministische Chain via `create_validate_chain(dsl=...)`.
           - Halte dich an das Format: `tool:step1 >> @agent >> CF(Model) - "key"`.
        4. SICHERHEIT: Neue Chains sind UNSAFE. Du musst sie beim ersten `run_chain` mit `accept=True` validieren.""",
                tools_used=["list_auto_get_fitting", "run_chain", "create_validate_chain"],
                tool_groups=["automation"],
                source="predefined"
            ),

            # === 9. VFS TASK PLANNING ===
            Skill(
                id="vfs_task_planning",
                name="Task Planning with Persistence",
                description="Use when planning multi-step tasks with persistent progress tracking in VFS, creating /plan.md, or tracking intermediate results",
                triggers=[
                    "plane", "aufgaben planen", "task planen", "todo liste",
                    "schritte planen", "workflow definieren", "mehrteilige aufgabe"
                ],
                instruction="""Für komplexe Aufgaben mit Planung:
        1. ZUERST: Nutze think() um die Aufgabe zu analysieren
        2. Erstelle Plan in /plan.md oder /[aufgabe]_plan.md:
           - Ziel der Aufgabe
           - Geschätzte Schritte (nummeriert)
           - Benötigte Tools/Ressourcen
           - Erfolgskriterien
        3. Arbeite Schritte ab und UPDATE den Plan:
           - [x] Erledigt
           - [ ] Offen
           - [!] Problem
        4. Zwischenergebnisse in /[aufgabe]/[schritt].md speichern
        5. Finale Zusammenfassung in /[aufgabe]_result.md
        6. Bei Unterbrechung: Plan zeigt wo weitermachen""",
                tools_used=["think", "vfs_write", "vfs_read", "vfs_mkdir", "vfs_list", "final_answer"],
                tool_groups=["vfs"],
                source="predefined"
            ),

            # ═══════════════════════════════════════════════════════════════
            # 🟡 ÜBERARBEITET (7) — Trigger repariert, Instructions verbessert
            # ═══════════════════════════════════════════════════════════════

            # === 10. AGENT ONBOARDING (ehemals habits_setup) ===
            Skill(
                id="agent_onboarding",
                name="Agent System Onboarding",
                description="Use when starting a new session, user asks what tools are available, or agent needs to understand the automation infrastructure",
                triggers=[
                    "onboarding", "was kannst du", "welche tools",
                    "wie funktioniert das system", "übersicht", "capabilities",
                    "was steht mir zur verfügung", "toolset", "job management",
                    "was sind chains", "was sind jobs"
                ],
                instruction="""DU HAST ZUGRIFF AUF FOLGENDE SYSTEME — nutze sie bewusst:

        1. CODER (isolierte Umgebung): Für ALLEN Code. spawn_coder() -> observe() -> validate_worktree() -> accept()
           NIEMALS Code direkt in VFS schreiben!

        2. CHAINS (deterministische Automatisierung): list_auto_get_fitting() -> run_chain()
           Für wiederkehrende Prozesse (Scraping, Reports, Deployments).

        3. JOBS (geplante Aufgaben): createJob(cron_expression=..., query=...) -> listJobs()
           Für zeitgesteuerte Tasks (täglich, wöchentlich).
           IMMER nach createJob() listJobs() aufrufen zur Verifizierung!

        4. SUB-AGENTS (parallele Ausführung): spawn_sub_agent(task=..., wait=False) -> wait_for()
           Für unabhängige Recherche- oder Datenverarbeitungsaufgaben.

        5. MEMORY (Langzeitgedächtnis): memory_recall() -> memory_analyse() -> memory_save()
           recall = schnell/konkret, analyse = tief/komplex, save = nur 'Ewige Wahrheiten'.

        6. VFS (Wissensspeicher): READ-ONLY für Code. vfs_write() NUR für Pläne/Markdown.
           Code-Änderungen gehen IMMER über den Coder.

        ENTSCHEIDUNGSLEITFADEN:
        - Code schreiben/ändern? -> Coder
        - Wiederkehrender Prozess? -> Chain
        - Zeitgesteuert? -> Job
        - Parallele Recherche? -> Sub-Agent
        - Fakten speichern? -> Memory
        - Pläne/Notizen? -> VFS (Markdown only)""",
                tools_used=["think", "final_answer"],
                tool_groups=[],
                source="predefined"
            ),

            # === 11. VFS STRICT USAGE (bulletproofed) ===
            Skill(
                id="vfs_strict_usage",
                name="Strict VFS Guidelines",
                description="Use when working with VFS files, especially when tempted to write code or configuration directly instead of using the Coder",
                triggers=[
                    "lese datei", "schreibe datei", "vfs", "ordner", "filesystem",
                    "datei erstellen", "datei bearbeiten"
                ],
                instruction="""**VFS = WISSENSSPEICHER, NICHT CODE-EDITOR.**

        VFS (Virtual File System) Richtlinien für den FlowAgent:

        1. READ-ONLY FÜR CODE: Du darfst Code-Dateien via `vfs_read` oder `vfs_grep` LESEN, um sie zu verstehen.
        2. NO CODE WRITING: Benutze `vfs_write`, `vfs_edit` oder `vfs_append` NIEMALS für Quellcode (.py, .js, .html etc.). Überlasse das dem CoderAgent!
        3. ERLAUBTE WRITES: Du darfst VFS-Write-Tools NUR nutzen für:
           - Markdown-Dateien für Pläne (/plan.md)
           - Readme-Aktualisierungen
           - Temporäre Log-Dateien
           - JSON-Konfigurationen (nach Bestätigung)
        4. ISOLIERUNG: Respektiere die Ordner von Sub-Agenten (/sub/...). Manipuliere deren Output nicht, bis sie fertig sind.

        **Violating the letter of the rules is violating the spirit of the rules.**

        ## Red Flags - STOP and Use Coder Instead
        - You're about to write a .py/.js/.html/.css file to VFS
        - "I just need to test this quickly" in VFS
        - Using vfs_write for code edits
        - "The sandbox is too slow" as a reason
        - "It's just a small change, I'll do it directly"

        ## Rationalization Table
        | Excuse | Reality |
        |--------|---------|
        | "Just this once, it's temporary" | Temporary writes become permanent. Use Coder. |
        | "The VFS is easier than Coder" | VFS is for knowledge only. Code goes to Coder. |
        | "I'll move it to sandbox later" | Later = never. Start in Coder. |
        | "This is config, not code" | Config changes need testing. Use Coder. |
        | "The Coder takes too long" | A broken codebase takes longer. |""",
                tools_used=["vfs_read", "vfs_grep", "vfs_list"],
                tool_groups=["vfs"],
                source="predefined"
            ),

            # === 12. USER PROFILE EDIT (trigger fix) ===
            Skill(
                id="user_profile_edit",
                name="User Profile Edit",
                description="Use when user wants to edit, delete, or correct their stored profile data or preferences",
                triggers=[
                    "profil löschen", "meine daten ändern", "profil bearbeiten",
                    "daten aktualisieren", "korrigiere mein profil", "das stimmt nicht",
                    "profil korrigieren", "entferne aus meinem profil"
                ],
                instruction="""Für Profil-Bearbeitungen:
        1. Identifiziere WAS geändert/gelöscht werden soll
        2. Lade aktuelles Profil
        3. Bei Löschung: Bestätige VOR dem Löschen was entfernt wird
        4. Bei Korrektur: Zeige alt vs. neu
        5. Bei Update: Merge mit existierenden Daten
        6. Speichere und bestätige die Änderung
        7. Bei "lösche alles": Doppelte Bestätigung erforderlich""",
                tools_used=["think", "file_read", "file_write", "final_answer"],
                tool_groups=["memory", "filesystem"],
                source="predefined"
            ),

            # === 13. ERROR RECOVERY (trigger fix + align_10 reference) ===
            Skill(
                id="error_recovery",
                name="Error Recovery",
                description="Use when encountering tool errors, exceptions, stacktraces, or unexpected failures that need structured diagnosis",
                triggers=[
                    "stacktrace", "exception", "traceback", "error code",
                    "tool fehler", "diagnose fehler", "crash analyse",
                    "returncode", "unexpected error"
                ],
                instruction="""Für Fehlerbehandlung — befolge align_10_four_phase_debug:

        1. ANALYSE: Sammle Symptome (Fehlermeldung, Return Code, Stacktrace)
        2. NARROW: Isoliere die fehlerhafte Komponente (welches Tool, welche Datei, welche Zeile)
        3. ROOT CAUSE: Identifiziere die exakte Ursache — nicht das Symptom
        4. FIX: Minimaler Patch, dann Verifikation

        Bei Tool-Fehler: Versuche alternativen Ansatz.
        Bei unklarer Ursache: Frage User nach mehr Kontext.
        Sei EHRLICH wenn du den Fehler nicht beheben kannst.
        Schlage nächste Schritte vor.""",
                tools_used=["think", "final_answer"],
                tool_groups=[],
                source="predefined"
            ),

            # === 14. MULTI STEP TASK (trigger fix) ===
            Skill(
                id="multi_step_task",
                name="Multi-Step Task Planning",
                description="Use when a task requires multiple sequential steps that must be coordinated, or when planning tool loading before execution",
                triggers=[
                    "mehrere schritte", "sequenzielle aufgabe", "koordinierte schritte",
                    "aufgabe mit mehreren phasen", "großes vorhaben", "mehrphasig"
                ],
                instruction="""Für komplexe Multi-Step Aufgaben:
        1. ZUERST: Nutze think() um einen Plan zu erstellen
        2. Liste alle benötigten Schritte auf (max 5-7)
        3. Identifiziere welche Tools du brauchen wirst
        4. Lade benötigte Tools VOR dem Start
        5. Führe Schritte SEQUENTIELL aus
        6. Nach jedem Schritt: Kurz verifizieren ob erfolgreich
        7. Bei Fehler: STOPPEN und User informieren
        8. Am Ende: Zusammenfassung was getan wurde

        Hinweis: Für Aufgaben die persistente Plan-Dateien benötigen, nutze vfs_task_planning.""",
                tools_used=["think", "list_tools", "load_tools", "final_answer"],
                tool_groups=[],
                source="predefined"
            ),

            # === 15. USER PROFILE MANAGER (pfade fix) ===
            Skill(
                id="user_profile_manager",
                name="User Profile Manager",
                description="Use when user asks who they are, what is known about them, or wants to see their stored profile",
                triggers=[
                    "profil", "profile", "wer bin ich", "who am i",
                    "was weißt du über mich", "what do you know about me",
                    "mein profil", "my profile", "zeig mein profil"
                ],
                instruction="""Für User Profile Management:
        1. Lade das User-Profil via memory_recall("user profile") oder world_model_get
        2. Bei Anfrage "wer bin ich" - fasse das Profil zusammen
        3. Bei Anfrage "was weißt du" - zeige relevante Kategorien
        4. Nutze think() um zu entscheiden welche Profilteile relevant sind
        5. Antworte personalisiert basierend auf dem Kontext
        6. Aktualisiere last_interaction Timestamp""",
                tools_used=["think", "memory_recall", "world_model_get", "final_answer"],
                tool_groups=["memory"],
                source="predefined"
            ),

            # === 16. VFS INFO PERSIST (abgrenzung zu user_preference_save) ===
            Skill(
                id="vfs_info_persist",
                name="Information Persistence",
                description="Use when persisting task results, notes, or structured information to VFS files — NOT for user preferences (use memory tools for those)",
                triggers=[
                    "speicher ergebnis", "notiz im vfs", "datei für später",
                    "vfs notiz", "aufgabe dokumentieren", "resultat speichern",
                    "zusammenfassung als datei"
                ],
                instruction="""Wenn Informationen als DATEIEN im VFS gespeichert werden sollen (nicht im Memory!):

        ABGRENZUNG: User-Präferenzen -> memory_save/memory_inject. Dateien/Pläne/Ergebnisse -> vfs_write.

        1. Identifiziere WAS gespeichert werden soll (Ergebnisse, Notizen, Pläne)
        2. Wähle passenden Speicherort:
           - /info/[thema].md für thematische Sammlungen
           - /[aufgabe]_result.md für Aufgaben-Ergebnisse
           - /notes.md für schnelle Notizen
        3. Strukturiere den Inhalt klar (Überschriften, Listen)
        4. Nutze vfs_write() um zu speichern
        5. Bestätige dem User WO und WAS gespeichert wurde
        6. Bei Updates: Erst vfs_read(), dann ergänzen, dann vfs_write()""",
                tools_used=["think", "vfs_read", "vfs_write", "vfs_list", "final_answer"],
                tool_groups=["vfs"],
                source="predefined"
            ),
        ]


        for skill in predefined:
            self.skills[skill.id] = skill

    # =========================================================================
    # SKILL MATCHING (Hybrid: Keyword → Embedding)
    # =========================================================================

    def match_skills(self, query: str, max_results: int = 3) -> List[Skill]:
        """
        Hybrid Matching: Keyword first, Embedding fallback.
        Returns matched skills sorted by relevance.
        """
        matched: List[Tuple[Skill, float]] = []

        # Phase 1: Keyword Matching (fast, predictable)
        for skill in self.skills.values():
            if not skill.is_active():
                continue
            if skill.matches_keywords(query):
                matched.append((skill, 1.0))  # Score 1.0 für keyword match

        # Sort by score, then by confidence
        matched.sort(key=lambda x: (x[1], x[0].confidence), reverse=True)

        return [skill for skill, _ in matched[:max_results]]

    async def match_skills_async(self, query: str, max_results: int = 3) -> List[Skill]:
        """
        Async version of match_skills with embedding fallback.
        """
        matched: List[Tuple[Skill, float]] = []

        # Phase 1: Keyword Matching
        for skill in self.skills.values():
            if not skill.is_active():
                continue
            if skill.matches_keywords(query):
                matched.append((skill, 1.0))

        # Phase 2: Embedding Fallback
        if self.match_embedding and len(matched) < max_results and self._memory:
            embedding_matches = await self._match_by_embedding(
                query,
                max_results - len(matched)
            )
            for skill, score in embedding_matches:
                if skill.id not in [s.id for s, _ in matched]:
                    matched.append((skill, score))

        matched.sort(key=lambda x: (x[1], x[0].confidence), reverse=True)
        return [skill for skill, _ in matched[:max_results]]

    async def _match_by_embedding(
        self,
        query: str,
        max_results: int
    ) -> List[Tuple[Skill, float]]:
        """Embedding-basiertes Matching mit mem.get_embeddings()"""
        if not self._memory:
            return []

        try:
            # Query Embedding (cached to prevent duplicate network requests)
            if not hasattr(self, '_query_embedding_cache'):
                self._query_embedding_cache = {}

            if query not in self._query_embedding_cache:
                embeddings = await self._memory.get_embeddings([query])
                self._query_embedding_cache[query] = embeddings[0]

            query_embedding = self._query_embedding_cache[query]

            # Ensure skill embeddings are cached
            await self._ensure_skill_embeddings()

            # Search in skill embeddings
            results = []
            for skill_id, embedding in self._skill_embeddings_cache.items():
                if skill_id not in self.skills:
                    continue
                skill = self.skills[skill_id]
                if not skill.is_active():
                    continue

                # Cosine similarity
                similarity = self._cosine_similarity(query_embedding, embedding)
                if similarity >= 0.5:  # Threshold
                    results.append((skill, float(similarity)))

            results.sort(key=lambda x: x[1], reverse=True)
            return results[:max_results]

        except Exception as e:
            _log.debug(f"[SkillsManager] Embedding match failed: {e}")
            return []

    async def _ensure_skill_embeddings(self):
        """Lazy load/update skill embeddings (Delta updates only)"""
        if not self._skill_embeddings_dirty:
            return

        if not self._memory:
            return

        try:
            texts = []
            skill_ids = []

            # Hash-Cache für Skills, um redundante API-Calls zu sparen
            if not hasattr(self, '_skill_text_hash_cache'):
                self._skill_text_hash_cache = {}

            for skill_id, skill in self.skills.items():
                if skill.is_active():
                    # Combine triggers and instruction for embedding
                    text = f"{skill.name} {' '.join(skill.triggers)} {skill.instruction[:200]}"
                    text_hash = hash(text)

                    # Nur re-embedden, wenn Skill neu ist oder Text sich geändert hat
                    if skill_id not in self._skill_embeddings_cache or self._skill_text_hash_cache.get(
                        skill_id) != text_hash:
                        texts.append(text)
                        skill_ids.append(skill_id)
                        self._skill_text_hash_cache[skill_id] = text_hash

            if texts:
                # API-Call nur für die wirklich geänderten/neuen Skills
                embeddings = await self._memory.get_embeddings(texts)
                for i, skill_id in enumerate(skill_ids):
                    self._skill_embeddings_cache[skill_id] = embeddings[i]

            self._skill_embeddings_dirty = False

        except Exception as e:
            _log.debug(f"[SkillsManager] Failed to create skill embeddings: {e}")

    def _cosine_similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        """Calculate cosine similarity between two vectors"""
        dot = np.dot(a, b)
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return dot / (norm_a * norm_b)

    def find_similar_skill(
        self,
        query: str,
        triggers: List[str],
        similarity_threshold: float = 0.5
    ) -> Optional[Skill]:
        """
        Find similar existing skill - INCLUDES INACTIVE SKILLS.
        Key fix: checks ALL skills, not just active ones.
        """
        best_match: Optional[Skill] = None
        best_score: float = 0.0

        query_lower = query.lower()
        new_triggers_lower = set(t.lower() for t in triggers)

        for skill in self.skills.values():
            if skill.source == "predefined":
                continue

            score = 0.0

            # Query matches existing triggers?
            if skill.matches_keywords(query):
                score += 0.5

            # Trigger overlap?
            existing_triggers_lower = set(t.lower() for t in skill.triggers)
            overlap = len(new_triggers_lower & existing_triggers_lower)
            if overlap > 0:
                overlap_ratio = overlap / max(len(new_triggers_lower), len(existing_triggers_lower))
                score += 0.5 * overlap_ratio

            if score > best_score and score >= similarity_threshold:
                best_score = score
                best_match = skill

        return best_match

    def _generate_skill_id(self, name: str) -> str:
        """Generate deterministic skill ID."""
        normalized = name.lower().replace(' ', '_').replace('-', '_')
        normalized = ''.join(c for c in normalized if c.isalnum() or c == '_')
        base_id = f"learned_{normalized[:20]}"

        if base_id not in self.skills:
            return base_id

        counter = 1
        while f"{base_id}_{counter}" in self.skills:
            counter += 1
        return f"{base_id}_{counter}"

    # =========================================================================
    # TOOL RELEVANCE SCORING (Keyword Overlap)
    # =========================================================================

    def score_tool_relevance(
        self,
        query: str,
        tool_name: str,
        tool_description: str
    ) -> float:
        """
        Calculate keyword-based relevance score for a tool.
        Called once at query start, results cached in ExecutionEngine.
        """
        query_words = set(query.lower().split())
        desc_words = set(tool_description.lower().split())
        name_words = set(tool_name.lower().replace('_', ' ').split())

        # Remove common stop words
        stop_words = {'der', 'die', 'das', 'und', 'oder', 'ein', 'eine', 'the', 'a', 'an', 'is', 'are', 'to', 'for'}
        query_words -= stop_words
        desc_words -= stop_words

        # Overlap berechnen
        query_desc_overlap = len(query_words & desc_words)
        query_name_overlap = len(query_words & name_words)

        # Score: Name match ist wichtiger als Description match
        score = 0.0
        if query_name_overlap > 0:
            score += 0.5 * min(1.0, query_name_overlap / max(1, len(name_words)))
        if query_desc_overlap > 0:
            score += 0.3 * min(1.0, query_desc_overlap / max(1, len(desc_words) / 3))

        # Bonus wenn Tool in matched Skills vorkommt
        matched_skills = self.match_skills(query, max_results=2)
        for skill in matched_skills:
            if tool_name in skill.tools_used:
                score += 0.3
                break

        return min(1.0, score)

    def get_relevant_tools_from_groups(
        self,
        query: str,
        tool_groups: List[str],
        tool_manager: Any,
        max_tools: int
    ) -> List[Tuple[str, float]]:
        """
        Get most relevant tools from given groups, sorted by relevance score.

        Returns: List of (tool_name, relevance_score) tuples
        """
        scored_tools = []

        for group_name in tool_groups:
            group = self.tool_groups.get(group_name)
            if not group:
                continue

            for tool_name in group.tool_names:
                tool_entry = tool_manager.get(tool_name)
                if tool_entry:
                    score = self.score_tool_relevance(
                        query,
                        tool_name,
                        tool_entry.description or ""
                    )
                    scored_tools.append((tool_name, score))

        # Sort by score descending
        scored_tools.sort(key=lambda x: x[1], reverse=True)

        return scored_tools[:max_tools]

    # =========================================================================
    # SKILL LEARNING
    # =========================================================================

    async def learn_from_run(
        self,
        query: str,
        tools_used: List[str],
        final_answer: str,
        success: bool,
        llm_completion_func: Callable
    ) -> Optional[Skill]:
        """
        Learn a new skill from a successful run.
        IMPROVED: Checks ALL skills (including inactive) for duplicates.
        """
        if not success:
            return None

        if len(tools_used) < 2:
            return None

        meaningful_tools = [t for t in tools_used if t not in ['think', 'final_answer', 'list_tools', 'load_tools']]
        if len(meaningful_tools) < 1:
            return None

        try:
            extraction_prompt = f"""Analysiere diesen erfolgreichen Ablauf und erstelle eine wiederverwendbare Anleitung.

    USER ANFRAGE: {query}

    TOOLS VERWENDET (in Reihenfolge): {', '.join(tools_used)}

    ERGEBNIS: {final_answer[:500]}

    Erstelle:
    1. Einen kurzen Namen für diesen Skill (max 5 Wörter, deutsch oder englisch)
    2. 3-5 Trigger-Keywords die ähnliche Anfragen erkennen würden
    3. Eine nummerierte Anleitung (4-6 Schritte) die beschreibt wie man ähnliche Aufgaben löst

    Format (EXAKT so):
    NAME: [skill name]
    TRIGGERS: [keyword1, keyword2, keyword3]
    ANLEITUNG:
    1. [Schritt 1]
    2. [Schritt 2]
    3. [Schritt 3]
    ..."""

            response = await llm_completion_func(
                messages=[{"role": "user", "content": extraction_prompt}],
                model_preference="fast",
                max_tokens=300,
                temperature=0.3,
                with_context=False
            )

            # Parse response
            parsed = self._parse_skill_response(response)
            if not parsed:
                return None

            name, triggers, instruction = parsed

            # ============================================================
            # KEY FIX: Check ALL skills (including inactive) for similarity
            # ============================================================
            similar_skill = self.find_similar_skill(query, triggers, similarity_threshold=0.4)

            if similar_skill:
                # MERGE into existing skill instead of creating duplicate
                old_confidence = similar_skill.confidence
                similar_skill.record_usage(
                    success=True,
                    query=query,
                    trigger_keyword=triggers[0] if triggers else "",
                )
                await similar_skill.merge_with(Skill(
                    id="temp",
                    name=name,
                    triggers=triggers,
                    instruction=instruction,
                    tools_used=list(set(tools_used))
                ))
                self._skill_embeddings_dirty = True

                _log.debug(f"[SkillsManager] Merged into existing skill: {similar_skill.name} "
                      f"(confidence: {similar_skill.confidence:.2f}, active: {similar_skill.is_active()})")

                # Audit-Log: Skill Merged
                try:
                    from toolboxv2 import get_app
                    app = get_app("CloudM.Isaa.Export")
                    if app and hasattr(app, 'audit_logger'):
                        app.audit_logger.log_action(
                            user_id="system",
                            action="agent.skill.merged",
                            resource=f"/agent/skills/{similar_skill.id}",
                            status="SUCCESS",
                            details={
                                "skill_id": similar_skill.id,
                                "name": similar_skill.name,
                                "confidence_before": old_confidence,
                                "confidence_after": similar_skill.confidence,
                                "triggers_added": triggers,
                                "tools_used": tools_used,
                            }
                        )
                except Exception:
                    pass

                return similar_skill

            # No similar skill - create new
            skill = Skill(
                id=self._generate_skill_id(name),
                name=name,
                triggers=triggers,
                instruction=instruction,
                tools_used=list(set(tools_used)),
                tool_groups=[],
                source="learned",
                confidence=0.61
            )

            self.skills[skill.id] = skill
            self._skill_embeddings_dirty = True
            _log.debug(f"[SkillsManager] Learned new skill: {skill.name} (confidence: {skill.confidence})")

            # Audit-Log: Skill Learned
            try:
                from toolboxv2 import get_app
                app = get_app("CloudM.Isaa.Export")
                if app and hasattr(app, 'audit_logger'):
                    app.audit_logger.log_action(
                        user_id="system",
                        action="agent.skill.learned",
                        resource=f"/agent/skills/{skill.id}",
                        status="SUCCESS",
                        details={
                            "skill_id": skill.id,
                            "name": skill.name,
                            "triggers": triggers,
                            "confidence": skill.confidence,
                            "tools_used": tools_used,
                            "source": "learned",
                        }
                    )
            except Exception:
                pass

            return skill

        except Exception as e:
            _log.debug(f"[SkillsManager] Failed to learn skill: {e}")
            import traceback
            traceback.print_exc()

        return None

    def _parse_skill_response(self, response: str) -> Optional[Tuple[str, List[str], str]]:
        """Parse LLM response into (name, triggers, instruction)."""
        try:
            lines = response.strip().split('\n')

            name = ""
            triggers = []
            instruction_lines = []
            in_instruction = False

            for line in lines:
                line = line.strip()
                if line.upper().startswith("NAME:"):
                    name = line[5:].strip()
                elif line.upper().startswith("TRIGGERS:"):
                    triggers_str = line[9:].strip().strip("[]")
                    triggers = [t.strip().strip('"\'') for t in triggers_str.split(',')]
                elif line.upper().startswith("ANLEITUNG:"):
                    in_instruction = True
                elif in_instruction and line:
                    instruction_lines.append(line)

            if not name or not triggers or not instruction_lines:
                return None

            return (name, triggers, '\n'.join(instruction_lines))

        except Exception as e:
            _log.debug(f"[SkillsManager] Failed to parse skill response: {e}")
            return None

    def record_skill_usage(
        self,
        skill_id: str,
        success: bool,
        query: str = "",
        trigger_keyword: str = "",
        iterations_used: int = 0,
    ) -> None:
        """Record skill usage with full context for effectiveness tracking."""
        if skill_id in self.skills:
            self.skills[skill_id].record_usage(
                success=success,
                query=query,
                trigger_keyword=trigger_keyword,
                iterations_used=iterations_used,
            )
            self._skill_embeddings_dirty = True

    def record_matched_skills_usage(
        self,
        matched_skills: list,
        success: bool,
        query: str = "",
        iterations_used: int = 0,
    ) -> None:
        """
        Convenience: record usage for all skills that were matched in a run.
        Called once per execute() / stream_generator() run.
        """
        for skill in (matched_skills or []):
            # Der Trigger-Keyword kommt aus dem ersten matching trigger
            trigger_kw = next(
                (t for t in getattr(skill, "triggers", []) if t.lower() in query.lower()),
                "",
            )
            self.record_skill_usage(
                skill_id=skill.id,
                success=success,
                query=query,
                trigger_keyword=trigger_kw,
                iterations_used=iterations_used,
            )

    # =========================================================================
    # TOOL GROUPS (migrated from rule_set.py)
    # =========================================================================

    def register_tool_group(
        self,
        name: str,
        display_name: str,
        tool_names: List[str],
        trigger_keywords: List[str],
        description: str = "",
        priority: int = 5,
        icon: str = "🔧",
        auto_generated: bool = False
    ):
        """Register a tool group"""
        self.tool_groups[name] = ToolGroup(
            name=name,
            display_name=display_name,
            description=description,
            tool_names=tool_names,
            trigger_keywords=trigger_keywords,
            priority=priority,
            icon=icon,
            auto_generated=auto_generated
        )

    def get_matching_tool_groups(self, query: str) -> List[ToolGroup]:
        """Get tool groups that match the query"""
        matched = []
        for group in self.tool_groups.values():
            if group.matches_query(query):
                matched.append(group)
        matched.sort(key=lambda g: g.priority)
        return matched

    def get_tool_group(self, name: str) -> Optional[ToolGroup]:
        """Get tool group by name"""
        return self.tool_groups.get(name)

    def list_tool_groups(self) -> List[str]:
        """List all tool group names"""
        return list(self.tool_groups.keys())

    def get_categories_from_groups(self) -> List[str]:
        """Get unique categories from all tool groups"""
        categories = set()
        for group in self.tool_groups.values():
            # Extract category from group name (e.g., "discord_tools" -> "discord")
            category = group.name.replace("_tools", "")
            categories.add(category)
        return sorted(list(categories))

    # =========================================================================
    # SKILL SHARING (Explicit)
    # =========================================================================

    def export_skill(self, skill_id: str) -> Optional[dict]:
        """Export a skill for sharing"""
        if skill_id in self.skills:
            return self.skills[skill_id].to_dict()
        return None

    def import_skill(self, skill_data: dict, overwrite: bool = False) -> bool:
        """Import a skill from another agent"""
        try:
            skill = Skill.from_dict(skill_data)

            if skill.id in self.skills and not overwrite:
                return False

            # Mark as imported
            skill.source = "imported"
            self.skills[skill.id] = skill
            self._skill_embeddings_dirty = True
            return True

        except Exception as e:
            _log.debug(f"[SkillsManager] Failed to import skill: {e}")
            return False

    def share_skill_with(
        self,
        skill_id: str,
        target_skills_manager: 'SkillsManager'
    ) -> bool:
        """Share a skill with another SkillsManager (via BindManager)"""
        skill_data = self.export_skill(skill_id)
        if skill_data:
            return target_skills_manager.import_skill(skill_data)
        return False

    def list_shareable_skills(self) -> List[dict]:
        """List skills that can be shared (active and high confidence)"""
        shareable = []
        for skill in self.skills.values():
            if skill.is_active() and skill.confidence >= 0.7:
                shareable.append({
                    'id': skill.id,
                    'name': skill.name,
                    'confidence': skill.confidence,
                    'success_count': skill.success_count,
                    'source': skill.source
                })
        return shareable

    # =========================================================================
    # SERIALIZATION
    # =========================================================================

    def to_checkpoint(self) -> dict:
        """Serialize for checkpoint"""
        return {
            'agent_name': self.agent_name,
            'skills': {sid: s.to_dict() for sid, s in self.skills.items()},
            'tool_groups': {gid: g.to_dict() for gid, g in self.tool_groups.items()}
        }

    def from_checkpoint(self, data: dict):
        """Restore from checkpoint"""
        # Restore skills (but keep predefined)
        predefined_ids = {s.id for s in self.skills.values() if s.source == "predefined"}

        for skill_id, skill_data in data.get('skills', {}).items():
            if skill_id in predefined_ids:
                # Update predefined skill stats only
                if skill_id in self.skills:
                    s = self.skills[skill_id]
                    s.success_count = skill_data.get('success_count', 0)
                    s.failure_count = skill_data.get('failure_count', 0)
                    s.confidence = skill_data.get('confidence', 1.0)
                    s.total_uses = skill_data.get('total_uses', 0)  # NEU
                    if skill_data.get('last_used'):  # NEU
                        try:
                            s.last_used = datetime.fromisoformat(skill_data['last_used'])
                        except (ValueError, TypeError):
                            pass
                    s.recent_queries = skill_data.get('recent_queries', [])
            else:
                # Restore learned/imported skills
                self.skills[skill_id] = Skill.from_dict(skill_data)

        # Restore tool groups
        self.tool_groups.clear()
        for group_id, group_data in data.get('tool_groups', {}).items():
            self.tool_groups[group_id] = ToolGroup.from_dict(group_data)

        self._skill_embeddings_dirty = True

    # =========================================================================
    # PROMPT BUILDING
    # =========================================================================

    def build_skill_prompt_section(self, matched_skills: List[Skill]) -> str:
        """Build prompt section for matched skills"""
        if not matched_skills:
            return ""

        lines = ["", "RELEVANTE SKILLS FÜR DIESE AUFGABE:"]
        for skill in matched_skills:
            lines.append(f"\n📚 [{skill.name}]")
            lines.append(skill.instruction)

        return '\n'.join(lines)

    # =========================================================================
    # STATISTICS
    # =========================================================================

    def get_stats(self) -> dict:
        """Get statistics"""
        active_skills = sum(1 for s in self.skills.values() if s.is_active())
        learned_skills = sum(1 for s in self.skills.values() if s.source == "learned")
        imported_skills = sum(1 for s in self.skills.values() if s.source == "imported")

        return {
            'total_skills': len(self.skills),
            'active_skills': active_skills,
            'learned_skills': learned_skills,
            'imported_skills': imported_skills,
            'predefined_skills': len(self.skills) - learned_skills - imported_skills,
            'tool_groups': len(self.tool_groups),
            'agent_name': self.agent_name
        }

    def __repr__(self) -> str:
        stats = self.get_stats()
        return f"<SkillsManager {self.agent_name} [{stats['active_skills']} active skills, {stats['tool_groups']} groups]>"


# =============================================================================
# AUTO GROUPING (migrated from rule_set.py)
# =============================================================================

def auto_group_tools_by_name_pattern(
    tool_manager: Any,
    skills_manager: SkillsManager,
    min_group_size: int = 2,
    separator: str = "_"
) -> Dict[str, List[str]]:
    """
    Automatically create tool groups based on repeating patterns in tool names.
    Migrated from rule_set.py

    Example:
        Tools: discord_send, discord_edit, discord_delete, github_clone, github_push
        Result: {
            "discord_tools": ["discord_send", "discord_edit", "discord_delete"],
            "github_tools": ["github_clone", "github_push"]
        }
    """
    ignore_prefixes = ["mcp", "a2a", "local"]
    ignore_suffixes = ["tool", "helper", "util", "utils"]

    all_tools = tool_manager.list_names()
    if not all_tools:
        return {}

    # Extract prefixes
    prefix_tools: Dict[str, List[str]] = defaultdict(list)

    for tool_name in all_tools:
        parts = tool_name.lower().split(separator)
        if len(parts) < 2:
            continue

        for prefix_len in range(1, min(3, len(parts))):
            prefix_parts = parts[:prefix_len]

            if prefix_parts[0] in ignore_prefixes:
                if len(prefix_parts) > 1:
                    prefix_parts = prefix_parts[1:]
                else:
                    continue

            if prefix_parts[-1] in ignore_suffixes:
                continue

            prefix = separator.join(prefix_parts)
            if len(prefix) >= 2:
                prefix_tools[prefix].append(tool_name)

    # Filter and resolve overlaps
    valid_groups: Dict[str, List[str]] = {}
    assigned_tools: set = set()

    sorted_prefixes = sorted(
        prefix_tools.items(),
        key=lambda x: (-len(x[0].split(separator)), -len(x[1]))
    )

    for prefix, tools in sorted_prefixes:
        available_tools = [t for t in tools if t not in assigned_tools]
        unique_tools = list(dict.fromkeys(available_tools))

        if len(unique_tools) >= min_group_size:
            group_name = f"{prefix}_tools"
            valid_groups[group_name] = unique_tools
            assigned_tools.update(unique_tools)

    # Register in SkillsManager
    for group_name, tool_names in valid_groups.items():
        display_parts = group_name.replace("_tools", "").split(separator)
        display_name = " ".join(word.capitalize() for word in display_parts) + " Tools"

        trigger_keywords = list(set(
            part for part in group_name.replace("_tools", "").split(separator)
            if part and len(part) > 1
        ))

        skills_manager.register_tool_group(
            name=group_name,
            display_name=display_name,
            tool_names=tool_names,
            trigger_keywords=trigger_keywords,
            description=f"Auto-grouped {len(tool_names)} tools",
            auto_generated=True
        )

    return valid_groups

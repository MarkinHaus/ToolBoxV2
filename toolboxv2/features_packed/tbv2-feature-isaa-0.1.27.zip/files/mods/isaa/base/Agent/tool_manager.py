"""
ToolManager - Unified Tool Registry for FlowAgent

Provides:
- Single registry for all tools (local, MCP, A2A)
- Category-based organization with flags
- Native LiteLLM format support
- RuleSet integration for automatic tool grouping

Author: FlowAgent V2
"""

import asyncio
import inspect
import json
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Any, Callable
from functools import wraps


# =============================================================================
# DATA STRUCTURES
# =============================================================================

@dataclass
class ToolEntry:
    """
    Unified tool entry supporting local functions, MCP tools, and A2A tools.
    """
    name: str
    description: str
    args_schema: str                          # "(arg1: str, arg2: int = 0)"

    # Categorization
    category: list[str] = field(default_factory=list)  # ['local', 'discord', 'mcp_filesystem']
    flags: dict[str, bool] = field(default_factory=dict)  # read, write, dangerous, etc.
    source: str = "local"                     # 'local', 'mcp', 'a2a', 'cli

    # Function reference (None when serialized/restored)
    function: Callable | None = None

    # Cached LiteLLM schema
    litellm_schema: dict | None = None

    # Metadata
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    call_count: int = 0
    last_called: datetime | None = None

    # MCP/A2A specific
    server_name: str | None = None            # For MCP/A2A: which server
    original_name: str | None = None          # Original tool name before prefixing

    #   # Health / Testing
    live_test_inputs: list[dict] = field(default_factory=list)
    cleanup_func: Callable | None = field(default=None, repr=False)
    result_contract: dict | None = None
    # result_contract schema:
    # {
    #   "allow_none": bool,            default True
    #   "allow_empty_string": bool,    default True
    #   "expected_type": str,          "str"|"dict"|"list"|"int"|"bool"|"float"|"any"
    #   "semantic_check_hint": str     hint für on-demand LLM-Validator
    # }
    health_status: str = "UNKNOWN"           # UNKNOWN|HEALTHY|DEGRADED|FAILED|GUARANTEED
    health_error: str | None = None
    last_health_check: datetime | None = None

    def __post_init__(self):
        """Ensure defaults and build schema"""
        if self.flags is None:
            self.flags = {}
        if self.category is None:
            self.category = []
        if self.metadata is None:
            self.metadata = {}

        # Set default flags based on name/description heuristics
        self._infer_flags()

    def _infer_flags(self):
        """Infer flags from tool name and description"""
        name_lower = self.name.lower()
        desc_lower = self.description.lower()

        # Read flag
        if 'read' not in self.flags:
            read_keywords = ['get', 'list', 'fetch', 'query', 'search', 'find', 'show', 'view']
            self.flags['read'] = any(kw in name_lower or kw in desc_lower for kw in read_keywords)

        # Write flag
        if 'write' not in self.flags:
            write_keywords = ['create', 'update', 'set', 'add', 'insert', 'modify', 'change']
            self.flags['write'] = any(kw in name_lower or kw in desc_lower for kw in write_keywords)

        # Save/Permanent write flag
        if 'save_write' not in self.flags:
            save_keywords = ['save', 'store', 'persist', 'permanent', 'commit']
            self.flags['save_write'] = any(kw in name_lower or kw in desc_lower for kw in save_keywords)

        # Dangerous flag
        if 'dangerous' not in self.flags:
            danger_keywords = ['delete', 'remove', 'drop', 'destroy', 'purge', 'clear', 'reset']
            self.flags['dangerous'] = any(kw in name_lower or kw in desc_lower for kw in danger_keywords)

        if 'guaranteed_healthy' not in self.flags:
            self.flags['guaranteed_healthy'] = False

        # Requires confirmation
        if 'requires_confirmation' not in self.flags:
            self.flags['requires_confirmation'] = self.flags.get('dangerous', False)

    def record_call(self):
        """Record that this tool was called"""
        self.call_count += 1
        self.last_called = datetime.now()

    def has_flag(self, flag_name: str) -> bool:
        """Check if tool has a specific flag enabled"""
        return self.flags.get(flag_name, False)

    def has_category(self, category: str) -> bool:
        """Check if tool belongs to category"""
        return category in self.category

    def matches_categories(self, categories: list[str]) -> bool:
        """Check if tool matches any of the given categories"""
        return bool(set(self.category) & set(categories))

    def matches_flags(self, **flags) -> bool:
        """Check if tool matches all given flag conditions"""
        for flag_name, required_value in flags.items():
            if self.flags.get(flag_name, False) != required_value:
                return False
        return True


@dataclass
class ToolHealthResult:
    """
    Ergebnis eines Health-Checks für ein einzelnes Tool.
    status: HEALTHY | DEGRADED | FAILED | SKIPPED | GUARANTEED
    """
    tool_name: str
    status: str
    error: str | None = None
    execution_time_ms: float = 0.0
    result_preview: str | None = None
    contract_violations: list[str] = field(default_factory=list)
    semantic_issues: list[str] = field(default_factory=list)

    def is_ok(self) -> bool:
        return self.status in ("HEALTHY", "GUARANTEED")

    def to_agent_message(self) -> str:
        """Transparente Darstellung für den Agent bei Execution-Fehlern."""
        parts = [f"[ToolHealthResult:{self.tool_name}] status={self.status}"]
        if self.error:
            parts.append(f"error={self.error}")
        if self.contract_violations:
            parts.append(f"contract_violations={self.contract_violations}")
        if self.semantic_issues:
            parts.append(f"semantic_issues={self.semantic_issues}")
        return " | ".join(parts)

# =============================================================================
# TOOL MANAGER
# =============================================================================

class ToolManager:
    """
    Unified tool registry managing local, MCP, and A2A tools.

    Features:
    - Single registry for all tool types
    - Category and flag-based filtering
    - Native LiteLLM format support
    - Automatic RuleSet integration
    """

    def __init__(self, rule_set: 'RuleSet | None' = None):
        """
        Initialize ToolManager.

        Args:
            rule_set: Optional RuleSet for automatic tool group registration
        """
        # Main registry
        self._registry: dict[str, ToolEntry] = {}

        # Indexes for fast lookups
        self._category_index: dict[str, set[str]] = {}  # category -> tool names
        self._flags_index: dict[str, set[str]] = {}     # flag -> tool names with flag=True
        self._source_index: dict[str, set[str]] = {}    # source -> tool names

        # RuleSet integration
        self._rule_set = rule_set

        # Statistics
        self._total_calls = 0
        # Pending checkpoint data for tools not yet registered by code
        self._pending_checkpoint_data: dict[str, dict[str, Any]] = {}

    # =========================================================================
    # REGISTRATION
    # =========================================================================

    def register(
        self,
        func: Callable | None,
        name: str | None = None,
        description: str | None = None,
        category: list[str] | str | None = None,
        flags: dict[str, bool] | None = None,
        source: str = "local",
        server_name: str | None = None,
        metadata: dict[str, Any] | None = None,
        args_schema: str | None = None,
        live_test_inputs: list[dict] | None = None,
        cleanup_func: Callable | None = None,
        result_contract: dict | None = None,
    ) -> ToolEntry:
        """
        Register a tool in the registry.

        Args:
            func: The callable function (can be None for MCP/A2A stubs)
            name: Tool name (defaults to function name)
            description: Tool description (defaults to docstring)
            category: Category or list of categories
            flags: Dict of flags (read, write, dangerous, etc.)
            source: Tool source ('local', 'mcp', 'a2a')
            server_name: For MCP/A2A: the server name
            metadata: Additional metadata
            args_schema: Override args schema string
            live_test_inputs: list
            cleanup_func: Callable
            result_contract: dict
                # result_contract schema:
                # {
                #   "allow_none": bool,            default True
                #   "allow_empty_string": bool,    default True
                #   "expected_type": str,          "str"|"dict"|"list"|"int"|"bool"|"float"|"any"
                #   "semantic_check_hint": str     hint für on-demand LLM-Validator
                # }

        Returns:
            Created ToolEntry
        """
        # Determine name
        tool_name = name
        if tool_name is None and func is not None:
            tool_name = func.__name__
        if tool_name is None:
            raise ValueError("Tool name required when func is None")

        # Determine description
        tool_description = description
        if tool_description is None and func is not None:
            tool_description = func.__doc__ or f"Tool: {tool_name}"
        if tool_description is None:
            tool_description = f"Tool: {tool_name}"

        # Ensure description is clean
        tool_description = tool_description.strip()[:2000]

        # Determine args schema
        if args_schema is None and func is not None:
            args_schema = self._get_args_schema(func)
        elif args_schema is None:
            args_schema = "()"

        # Normalize category
        if category is None:
            category = [source]
        elif isinstance(category, str):
            category = [category]

        # Ensure source is in category
        if source not in category:
            category.append(source)

        # Wrap sync functions as async
        effective_func = func
        if func is not None and not asyncio.iscoroutinefunction(func):
            # NEU: Check ob Tool GUI-blocking ist und Main Thread braucht
            no_thread = (flags or {}).get("no_thread", False)

            if no_thread:
                @wraps(func)
                async def async_wrapper_direct(*args, **kwargs):
                    """Direkt auf Event-Loop Thread - für GUI/Win32 Calls"""
                    return func(*args, **kwargs)

                effective_func = async_wrapper_direct
            else:
                @wraps(func)
                async def async_wrapper(*args, **kwargs):
                    return await asyncio.to_thread(func, *args, **kwargs)

                effective_func = async_wrapper

        # Create entry
        entry = ToolEntry(
            name=tool_name,
            description=tool_description,
            args_schema=args_schema,
            category=category,
            flags=flags or {},
            source=source,
            function=effective_func,
            server_name=server_name,
            original_name=name if server_name else None,
            metadata=metadata or {}
        )

        # Health / Testing fields
        if live_test_inputs is not None:
            entry.live_test_inputs = live_test_inputs
        if cleanup_func is not None:
            entry.cleanup_func = cleanup_func
        if result_contract is not None:
            entry.result_contract = result_contract

        if tool_name in self._pending_checkpoint_data:
            pending_data = self._pending_checkpoint_data.pop(tool_name)

            # Übernehme Laufzeit-Statistiken aus Checkpoint
            entry.call_count = pending_data.get('call_count', 0)

            # Übernehme Timestamps
            if pending_data.get('last_called'):
                entry.last_called = datetime.fromisoformat(pending_data['last_called'])
            if pending_data.get('created_at'):
                entry.created_at = datetime.fromisoformat(pending_data['created_at'])

            # Merge metadata (pending ergänzt das aktuelle metadata)
            pending_metadata = pending_data.get('metadata', {})
            if pending_metadata:
                # Aktuelles metadata hat Priorität, pending füllt Lücken
                merged_metadata = {**pending_metadata, **entry.metadata}
                entry.metadata = merged_metadata

        # Build LiteLLM schema
        entry.litellm_schema = self._build_litellm_schema(entry)

        # Store in registry
        self._registry[tool_name] = entry
        # Update indexes
        self._update_indexes(entry)

        # Sync to RuleSet if available
        if self._rule_set:
            self._sync_tool_to_ruleset(entry)

        return entry


    def un_register(self, name: str) -> bool:
        """Remove a tool from the registry"""
        if name not in self._registry:
            return False

        del self._registry[name]
        return True

    def register_mcp_tools(
        self,
        server_name: str,
        tools: list[dict[str, Any]],
        category_prefix: str = "mcp"
    ):
        """
        Register multiple MCP tools from a server.

        Args:
            server_name: Name of the MCP server
            tools: List of tool configs from MCP server
                   Each should have: name, description, inputSchema
            category_prefix: Prefix for category (default: "mcp")
        """
        for tool_config in tools:
            original_name = tool_config.get('name', 'unknown')
            prefixed_name = f"{server_name}_{original_name}"

            # Extract args schema from inputSchema
            input_schema = tool_config.get('inputSchema', {})
            args_schema = self._schema_to_args_string(input_schema)

            self.register(
                func=None,  # MCP tools don't have local functions
                name=prefixed_name,
                description=tool_config.get('description', f"MCP tool: {original_name}"),
                category=[f"{category_prefix}_{server_name}", category_prefix, server_name],
                source="mcp",
                server_name=server_name,
                args_schema=args_schema,
                metadata={
                    'input_schema': input_schema,
                    'original_config': tool_config
                }
            )

    def register_a2a_tools(
        self,
        server_name: str,
        tools: list[dict[str, Any]],
        category_prefix: str = "a2a"
    ):
        """
        Register multiple A2A tools from a server.

        Args:
            server_name: Name of the A2A server
            tools: List of tool configs from A2A server
            category_prefix: Prefix for category (default: "a2a")
        """
        for tool_config in tools:
            original_name = tool_config.get('name', 'unknown')
            prefixed_name = f"{server_name}_{original_name}"

            self.register(
                func=None,  # A2A tools don't have local functions
                name=prefixed_name,
                description=tool_config.get('description', f"A2A tool: {original_name}"),
                category=[f"{category_prefix}_{server_name}", category_prefix, server_name],
                source="a2a",
                server_name=server_name,
                metadata={
                    'original_config': tool_config
                }
            )

    def unregister(self, name: str) -> bool:
        """Remove a tool from the registry"""
        if name not in self._registry:
            return False

        entry = self._registry[name]

        # Remove from indexes
        for cat in entry.category:
            if cat in self._category_index:
                self._category_index[cat].discard(name)

        for flag_name, flag_value in entry.flags.items():
            if flag_value and flag_name in self._flags_index:
                self._flags_index[flag_name].discard(name)

        if entry.source in self._source_index:
            self._source_index[entry.source].discard(name)

        # Remove from registry
        del self._registry[name]

        return True

    def update(self, name: str, **updates) -> bool:
        """Update a tool's attributes"""
        if name not in self._registry:
            return False

        entry = self._registry[name]

        # Store old values for index update
        old_categories = entry.category.copy()
        old_flags = entry.flags.copy()

        # Apply updates
        for key, value in updates.items():
            if hasattr(entry, key):
                setattr(entry, key, value)

        # Rebuild LiteLLM schema if description or args changed
        if 'description' in updates or 'args_schema' in updates:
            entry.litellm_schema = self._build_litellm_schema(entry)

        # Update indexes if category or flags changed
        if 'category' in updates or 'flags' in updates:
            # Remove from old indexes
            for cat in old_categories:
                if cat in self._category_index:
                    self._category_index[cat].discard(name)
            for flag_name, flag_value in old_flags.items():
                if flag_value and flag_name in self._flags_index:
                    self._flags_index[flag_name].discard(name)

            # Add to new indexes
            self._update_indexes(entry)

        return True

    def _update_indexes(self, entry: ToolEntry):
        """Update indexes for a tool entry"""
        # Category index
        for cat in entry.category:
            if cat not in self._category_index:
                self._category_index[cat] = set()
            self._category_index[cat].add(entry.name)

        # Flags index
        for flag_name, flag_value in entry.flags.items():
            if flag_value:
                if flag_name not in self._flags_index:
                    self._flags_index[flag_name] = set()
                self._flags_index[flag_name].add(entry.name)

        # Source index
        if entry.source not in self._source_index:
            self._source_index[entry.source] = set()
        self._source_index[entry.source].add(entry.name)

    # =========================================================================
    # QUERIES
    # =========================================================================

    def get(self, name: str) -> ToolEntry | None:
        """Get tool entry by name"""
        return self._registry.get(name)

    def get_function(self, name: str) -> Callable | None:
        """Get tool function by name"""
        entry = self._registry.get(name)
        return entry.function if entry else None

    def get_by_category(self, *categories: str) -> list[ToolEntry]:
        """
        Get tools matching any of the given categories.

        Args:
            *categories: Category names to match

        Returns:
            List of matching ToolEntries
        """
        matching_names: set[str] = set()

        for cat in categories:
            if cat in self._category_index:
                matching_names.update(self._category_index[cat])

        return [self._registry[name] for name in matching_names if name in self._registry]

    def get_by_flags(self, **flags: bool) -> list[ToolEntry]:
        """
        Get tools matching all given flag conditions.

        Args:
            **flags: Flag conditions (e.g., read=True, dangerous=False)

        Returns:
            List of matching ToolEntries
        """
        # Start with all tools
        candidates = set(self._registry.keys())

        for flag_name, required_value in flags.items():
            if required_value:
                # Must have flag = True
                if flag_name in self._flags_index:
                    candidates &= self._flags_index[flag_name]
                else:
                    candidates = set()  # No tools have this flag
            else:
                # Must NOT have flag = True
                if flag_name in self._flags_index:
                    candidates -= self._flags_index[flag_name]

        return [self._registry[name] for name in candidates]

    def get_by_source(self, source: str) -> list[ToolEntry]:
        """Get tools by source (local, mcp, a2a)"""
        if source in self._source_index:
            return [self._registry[name] for name in self._source_index[source] if name in self._registry]
        return []

    def get_all(self) -> list[ToolEntry]:
        """Get all registered tools"""
        return list(self._registry.values())

    def list_names(self) -> list[str]:
        """Get list of all tool names"""
        return list(self._registry.keys())

    def list_categories(self) -> list[str]:
        """Get list of all categories"""
        return list(self._category_index.keys())

    def exists(self, name: str) -> bool:
        """Check if tool exists"""
        return name in self._registry

    def count(self) -> int:
        """Get total number of registered tools"""
        return len(self._registry)

    def get_stats(self) -> dict[str, Any]:
        """Get registry statistics"""
        return {
            'total_tools': len(self._registry),
            'by_source': {
                source: len(names)
                for source, names in self._source_index.items()
            },
            'categories': list(self._category_index.keys()),
            'total_calls': self._total_calls
        }

    # =========================================================================
    # LITELLM FORMAT
    # =========================================================================

    def get_litellm_schema(self, name: str) -> dict | None:
        """Get cached LiteLLM schema for a tool"""
        entry = self._registry.get(name)
        if entry:
            return entry.litellm_schema
        return None

    def get_all_litellm(
        self,
        filter_categories: list[str] | None = None,
        filter_flags: dict[str, bool] | None = None,
        exclude_categories: list[str] | None = None,
        max_tools: int | None = None
    ) -> list[dict]:
        """
        Get all tools in LiteLLM format with optional filtering.

        Args:
            filter_categories: Only include tools with these categories
            filter_flags: Only include tools matching these flag conditions
            exclude_categories: Exclude tools with these categories
            max_tools: Maximum number of tools to return

        Returns:
            List of tool schemas in LiteLLM format
        """
        candidates = self.get_all()

        # Filter by categories
        if filter_categories:
            candidates = [e for e in candidates if e.matches_categories(filter_categories)]

        # Exclude categories
        if exclude_categories:
            candidates = [e for e in candidates if not e.matches_categories(exclude_categories)]

        # Filter by flags
        if filter_flags:
            candidates = [e for e in candidates if e.matches_flags(**filter_flags)]

        # Apply limit
        if max_tools and len(candidates) > max_tools:
            candidates = candidates[:max_tools]

        # Return LiteLLM schemas
        return [e.litellm_schema for e in candidates if e.litellm_schema]

    def _build_litellm_schema(self, entry: ToolEntry) -> dict:
        """
        Build LiteLLM/OpenAI function calling schema for a tool.
        """
        # Parse args schema to properties
        properties, required = self._parse_args_schema(entry.args_schema)

        return {
            "type": "function",
            "function": {
                "name": entry.name,
                "description": entry.description[:1024],  # OpenAI limit
                "parameters": {
                    "type": "object",
                    "properties": properties,
                    "required": required
                }
            }
        }

    def _get_args_schema(self, func: Callable) -> str:
        """Generate args schema string from function signature"""
        try:
            sig = inspect.signature(func)
            parts = []

            for name, param in sig.parameters.items():
                if name in ('self', 'cls', 'args', 'kwargs'):
                    continue

                # Get type annotation
                ann = ""
                if param.annotation != inspect.Parameter.empty:
                    ann = f": {self._annotation_to_str(param.annotation)}"

                # Get default value
                default = ""
                if param.default != inspect.Parameter.empty:
                    default = f" = {repr(param.default)}"

                # Handle *args and **kwargs
                prefix = ""
                if param.kind == inspect.Parameter.VAR_POSITIONAL:
                    prefix = "*"
                elif param.kind == inspect.Parameter.VAR_KEYWORD:
                    prefix = "**"

                parts.append(f"{prefix}{name}{ann}{default}")

            return f"({', '.join(parts)})"
        except Exception:
            return "()"

    def _annotation_to_str(self, annotation) -> str:
        """Convert type annotation to string"""
        import typing

        if isinstance(annotation, str):
            return annotation

        # Handle Optional, Union
        if getattr(annotation, "__origin__", None) is typing.Union:
            args = annotation.__args__
            if len(args) == 2 and type(None) in args:
                non_none = args[0] if args[1] is type(None) else args[1]
                return f"Optional[{self._annotation_to_str(non_none)}]"
            return " | ".join(self._annotation_to_str(a) for a in args)

        # Handle generics
        if hasattr(annotation, "__origin__"):
            origin = getattr(annotation.__origin__, "__name__", str(annotation.__origin__))
            args = getattr(annotation, "__args__", None)
            if args:
                return f"{origin}[{', '.join(self._annotation_to_str(a) for a in args)}]"
            return origin

        # Handle normal types
        if hasattr(annotation, "__name__"):
            return annotation.__name__

        return str(annotation)

    def _parse_args_schema(self, args_schema: str) -> tuple[dict, list]:
        """
        Parse args schema string to LiteLLM properties format.

        Args:
            args_schema: String like "(arg1: str, arg2: int = 0)"

        Returns:
            Tuple of (properties dict, required list)
        """
        properties = {}
        required = []

        if not args_schema or args_schema == "()":
            return properties, required

        # Remove parentheses
        inner = args_schema.strip("()")
        if not inner:
            return properties, required

        # Split by comma (handling nested brackets)
        parts = self._split_args(inner)

        for part in parts:
            part = part.strip()
            if not part or part.startswith('*'):
                continue

            # Parse "name: type = default" format
            has_default = "=" in part

            if ":" in part:
                name_part = part.split(":")[0].strip()
                type_part = part.split(":")[1].strip()

                if "=" in type_part:
                    type_part = type_part.split("=")[0].strip()

                # Detect nullable wrappers that Python's typing produces:
                #   Optional[X]        -> nullable X
                #   X | None           -> nullable X  (PEP 604)
                #   None | X           -> nullable X
                #   Union[X, None]     -> nullable X
                is_nullable = False
                inner_type = type_part
                stripped = type_part.replace(" ", "")

                if stripped.startswith("Optional[") and stripped.endswith("]"):
                    is_nullable = True
                    inner_type = stripped[len("Optional["):-1]
                elif "|" in stripped:
                    union_parts = [p.strip() for p in stripped.split("|")]
                    if "None" in union_parts:
                        is_nullable = True
                        non_none = [p for p in union_parts if p != "None"]
                        # If multiple non-None alternatives, fall back to first; JSON Schema
                        # can't express arbitrary unions for tool params reliably across providers.
                        inner_type = non_none[0] if non_none else "str"
                elif stripped.startswith("Union[") and stripped.endswith("]"):
                    union_inner = stripped[len("Union["):-1]
                    union_parts = [p.strip() for p in self._split_args(union_inner)]
                    if "None" in union_parts or "NoneType" in union_parts:
                        is_nullable = True
                        non_none = [p for p in union_parts if p not in ("None", "NoneType")]
                        inner_type = non_none[0] if non_none else "str"

                json_type = self._python_type_to_json(inner_type)

                # Groq/OpenAI strict mode requires nullable params to use
                type_field = [json_type, "null"] if is_nullable else json_type

                properties[name_part] = {
                    "type": type_field,
                    "description": f"Parameter: {name_part}"
                }

                if not has_default:
                    required.append(name_part)
            else:
                # No type annotation
                name_part = part.split("=")[0].strip() if "=" in part else part.strip()

                # If param has a default (typically None), treat as optional + nullable
                type_field = ["string", "null"] if has_default else "string"

                properties[name_part] = {
                    "type": type_field,
                    "description": f"Parameter: {name_part}"
                }

                if not has_default:
                    required.append(name_part)

        return properties, required

    def _split_args(self, args_str: str) -> list[str]:
        """Split args string by comma, handling nested brackets"""
        parts = []
        current = ""
        bracket_count = 0

        for char in args_str:
            if char in "([{":
                bracket_count += 1
            elif char in ")]}":
                bracket_count -= 1
            elif char == "," and bracket_count == 0:
                parts.append(current)
                current = ""
                continue

            current += char

        if current:
            parts.append(current)

        return parts

    def _python_type_to_json(self, type_str: str) -> str:
        type_map = {
            "str": "string", "string": "string",
            "int": "integer", "integer": "integer",
            "float": "number", "number": "number",
            "bool": "boolean", "boolean": "boolean",
            "list": "array", "array": "array",
            "dict": "object", "object": "object",
            "any": "string",
        }
        type_lower = type_str.lower().split("[")[0].strip()
        if type_lower not in type_map:
            # Surface unknown types instead of silently defaulting to string
            from toolboxv2 import get_logger
            get_logger().debug(
                f"_python_type_to_json: unknown type {type_str!r}, defaulting to string"
            )
        return type_map.get(type_lower, "string")

    def _schema_to_args_string(self, input_schema: dict) -> str:
        """Convert JSON Schema to args string"""
        if not input_schema:
            return "()"

        properties = input_schema.get("properties", {})
        required = set(input_schema.get("required", []))

        parts = []
        for name, prop in properties.items():
            prop_type = prop.get("type", "string")

            # Map JSON type to Python
            type_map = {
                "string": "str",
                "integer": "int",
                "number": "float",
                "boolean": "bool",
                "array": "list",
                "object": "dict"
            }

            python_type = type_map.get(prop_type, "Any")

            if name in required:
                parts.append(f"{name}: {python_type}")
            else:
                parts.append(f"{name}: {python_type} = None")

        return f"({', '.join(parts)})"

    # =========================================================================
    # EXECUTION
    # =========================================================================

    async def execute(self, function_name: str, **kwargs) -> Any:
        """
        Execute a tool by name.

        Args:
            function_name: Tool name
            **kwargs: Arguments to pass to the tool

        Returns:
            Tool execution result

        Raises:
            ValueError: If tool not found
            RuntimeError: If tool has no function (MCP/A2A)
        """
        entry = self._registry.get(function_name)

        if entry is None:
            raise ValueError(f"Tool not found: {function_name}")

        if entry.function is None:
            raise RuntimeError(
                f"Tool '{function_name}' has no local function. "
                f"It's a {entry.source} tool from server '{entry.server_name}'. "
                f"Use the appropriate {entry.source} client to execute it."
            )

        # Record call
        entry.record_call()
        self._total_calls += 1

        # Execute
        import time
        start_time = time.time()

        try:
            if asyncio.iscoroutinefunction(entry.function):
                result = await entry.function(**kwargs)
            else:
                result = entry.function(**kwargs)

            # Handle coroutine result
            if asyncio.iscoroutine(result):
                result = await result

            # --- Result Contract Validation (transparent für den Agent) ---
            contract = entry.result_contract or {}
            contract_violations = []

            if not contract.get("allow_none", True) and result is None:
                contract_violations.append("result is None but allow_none=False")

            if not contract.get("allow_empty_string", True) and result == "":
                contract_violations.append("result is empty string but allow_empty_string=False")

            expected_type = contract.get("expected_type", "any")
            if expected_type != "any" and result is not None:
                _type_map = {"str": str, "dict": dict, "list": list, "int": int, "bool": bool, "float": float}
                if expected_type in _type_map and not isinstance(result, _type_map[expected_type]):
                    contract_violations.append(f"expected_type={expected_type}, got={type(result).__name__}")

            if contract_violations:
                hint = contract.get("semantic_check_hint", "")
                raise ValueError(
                    f"Tool '{function_name}' result_contract violation: {contract_violations}"
                    + (f" | semantic_hint: {hint}" if hint else "")
                )

            execution_time = time.time() - start_time

            # Audit-Log: Tool Executed Success
            try:
                from toolboxv2 import get_app
                app = get_app("CloudM.Isaa.Export")
                if app and hasattr(app, 'audit_logger'):
                    app.audit_logger.log_action(
                        user_id="system",
                        action="agent.tool.executed",
                        resource=f"/agent/tools/{function_name}",
                        status="SUCCESS",
                        details={
                            "tool_name": function_name,
                            "tool_source": entry.source,
                            "args_count": len(kwargs),
                            "execution_time_ms": round(execution_time * 1000, 2),
                            "call_count": entry.call_count,
                        }
                    )
            except Exception:
                pass

            return result

        except Exception as e:
            execution_time = time.time() - start_time
            error_msg = str(e)
            if len(error_msg) > 400:
                error_msg = error_msg[:200] + " [...] " + error_msg[-200:]

            # Audit-Log: Tool Executed Error
            try:
                from toolboxv2 import get_app
                app = get_app("CloudM.Isaa.Export")
                if app and hasattr(app, 'audit_logger'):
                    app.audit_logger.log_action(
                        user_id="system",
                        action="agent.tool.error",
                        resource=f"/agent/tools/{function_name}",
                        status="FAILURE",
                        details={
                            "tool_name": function_name,
                            "tool_source": entry.source,
                            "error_type": type(e).__name__,
                            "error_message": error_msg,
                            "execution_time_ms": round(execution_time * 1000, 2),
                        }
                    )
            except Exception:
                pass
            raise

    # =========================================================================
    # HEALTH CHCK
    # =========================================================================

    async def health_check_single(self, name: str) -> 'ToolHealthResult':
        """
        Führt einen Health-Check für ein einzelnes Tool aus.

        Logik:
          - guaranteed_healthy flag → GUARANTEED, kein execution
          - keine live_test_inputs + kein guaranteed → SKIPPED
          - MCP/A2A (function=None) → SKIPPED
          - sonst: execution mit live_test_inputs[0], contract validation, cleanup
        """
        entry = self._registry.get(name)
        if entry is None:
            return ToolHealthResult(tool_name=name, status="FAILED", error="Tool not found in registry")

        # GUARANTEED: manuell als stabil markiert
        if entry.flags.get("guaranteed_healthy", False):
            entry.health_status = "GUARANTEED"
            entry.last_health_check = datetime.now()
            return ToolHealthResult(tool_name=name, status="GUARANTEED")

        # Kein live test möglich
        if not entry.live_test_inputs:
            return ToolHealthResult(
                tool_name=name,
                status="SKIPPED",
                error="No live_test_inputs provided — set guaranteed_healthy=True if manually verified"
            )

        # MCP/A2A ohne lokale function
        if entry.function is None:
            return ToolHealthResult(
                tool_name=name,
                status="SKIPPED",
                error=f"{entry.source} tool has no local function"
            )

        test_input = entry.live_test_inputs[0]
        violations: list[str] = []
        start = time.time()

        try:
            if asyncio.iscoroutinefunction(entry.function):
                result = await entry.function(**test_input)
            else:
                result = entry.function(**test_input)

            if asyncio.iscoroutine(result):
                result = await result

            exec_ms = (time.time() - start) * 1000

            # --- Contract Validation ---
            contract = entry.result_contract or {}

            if not contract.get("allow_none", True) and result is None:
                violations.append("result is None but allow_none=False")

            if not contract.get("allow_empty_string", True) and result == "":
                violations.append("result is empty string but allow_empty_string=False")

            expected_type = contract.get("expected_type", "any")
            if expected_type != "any" and result is not None:
                _type_map = {
                    "str": str, "dict": dict, "list": list,
                    "int": int, "bool": bool, "float": float
                }
                if expected_type in _type_map and not isinstance(result, _type_map[expected_type]):
                    violations.append(
                        f"expected_type={expected_type}, got={type(result).__name__}"
                    )

            # --- Cleanup ---
            if entry.cleanup_func is not None:
                try:
                    cleanup_result = entry.cleanup_func(test_input, result)
                    if asyncio.iscoroutine(cleanup_result):
                        await cleanup_result
                except Exception as ce:
                    violations.append(f"cleanup_func raised: {ce}")

            result_preview = repr(result)[:200] if result is not None else "None"

            if violations:
                entry.health_status = "DEGRADED"
                entry.health_error = "; ".join(violations)
                entry.last_health_check = datetime.now()
                return ToolHealthResult(
                    tool_name=name,
                    status="DEGRADED",
                    execution_time_ms=exec_ms,
                    result_preview=result_preview,
                    contract_violations=violations
                )

            entry.health_status = "HEALTHY"
            entry.health_error = None
            entry.last_health_check = datetime.now()
            return ToolHealthResult(
                tool_name=name,
                status="HEALTHY",
                execution_time_ms=exec_ms,
                result_preview=result_preview
            )
        except asyncio.CancelledError:
            raise
        except Exception as e:
            exec_ms = (time.time() - start) * 1000
            entry.health_status = "FAILED"
            entry.health_error = str(e)
            entry.last_health_check = datetime.now()
            return ToolHealthResult(
                tool_name=name,
                status="FAILED",
                error=str(e),
                execution_time_ms=exec_ms
            )

    async def health_check_all(self) -> dict[str, 'ToolHealthResult']:
        """
        Health-Check für alle registrierten Tools.
        Returns: dict tool_name → ToolHealthResult
        """
        results: dict[str, ToolHealthResult] = {}
        for name in list(self._registry.keys()):
            results[name] = await self.health_check_single(name)
        return results

    def is_healthy(self, name: str) -> bool:
        """True wenn tool HEALTHY oder GUARANTEED ist."""
        entry = self._registry.get(name)
        if entry is None:
            return False
        return entry.health_status in ("HEALTHY", "GUARANTEED")

    async def semantic_check(
        self,
        name: str,
        result: Any,
        llm_caller: Callable[[str], Any]
    ) -> list[str]:
        """
        On-demand LLM-basierter Semantic-Check eines Tool-Results.
        Nur aufrufen wenn semantic_check_hint im result_contract gesetzt ist.

        Args:
            name:        Tool-Name
            result:      Das tatsächliche Execution-Result
            llm_caller:  async callable(prompt: str) -> str

        Returns:
            Liste von semantischen Widersprüchen, leer wenn OK.
        """
        entry = self._registry.get(name)
        if entry is None:
            return [f"Tool '{name}' not found"]

        hint = (entry.result_contract or {}).get("semantic_check_hint")
        if not hint:
            return []

        prompt = (
            f"Tool: {name}\n"
            f"Description: {entry.description[:300]}\n"
            f"Result: {repr(result)[:600]}\n"
            f"Semantic check: {hint}\n"
            f"List any contradictions or inconsistencies as bullet points. "
            f"If result is semantically consistent, reply only: OK"
        )

        try:
            response = await llm_caller(prompt)
            response = response.strip()
            if response.upper() == "OK" or response.upper().startswith("OK"):
                return []
            return [line.strip("- ").strip() for line in response.splitlines() if line.strip()]
        except Exception as e:
            return [f"semantic_check failed: {e}"]

    # =========================================================================
    # RULESET INTEGRATION
    # =========================================================================

    def set_ruleset(self, rule_set: 'RuleSet'):
        """Set RuleSet for automatic tool group registration"""
        self._rule_set = rule_set
        # Sync all existing tools
        self._sync_all_to_ruleset()

    def _sync_all_to_ruleset(self):
        """Sync all tools to RuleSet as tool groups"""
        if not self._rule_set:
            return

        # Group tools by category
        category_tools: dict[str, list[str]] = {}

        for entry in self._registry.values():
            for cat in entry.category:
                if cat not in category_tools:
                    category_tools[cat] = []
                category_tools[cat].append(entry.name)

        # Register as tool groups
        self._rule_set.register_tool_groups_from_categories(category_tools)

    def _sync_tool_to_ruleset(self, entry: ToolEntry):
        """Sync a single tool to RuleSet"""
        if not self._rule_set:
            return

        # Update tool groups for this tool's categories
        for cat in entry.category:
            group_name = f"{cat}_tools"

            if group_name in self._rule_set.tool_groups:
                # Add to existing group
                if entry.name not in self._rule_set.tool_groups[group_name].tool_names:
                    self._rule_set.tool_groups[group_name].tool_names.append(entry.name)
            else:
                # Create new group
                self._rule_set.register_tool_group(
                    name=group_name,
                    display_name=f"{cat.replace('_', ' ').title()} Tools",
                    tool_names=[entry.name],
                    trigger_keywords=[cat],
                    auto_generated=True
                )

    # =========================================================================
    # SERIALIZATION
    # =========================================================================

    def to_checkpoint(self) -> dict[str, Any]:
        """
        Serialize registry for checkpoint.
        Note: Function references are NOT serialized.
        """
        return {
            'tools': {
                name: {
                    'name': entry.name,
                    'description': entry.description,
                    'args_schema': entry.args_schema,
                    'category': entry.category,
                    'flags': entry.flags,
                    'source': entry.source,
                    'server_name': entry.server_name,
                    'original_name': entry.original_name,
                    'metadata': entry.metadata,
                    'created_at': entry.created_at.isoformat(),
                    'call_count': entry.call_count,
                    'last_called': entry.last_called.isoformat() if entry.last_called else None,
                    'litellm_schema': entry.litellm_schema
                }
                for name, entry in self._registry.items()
            },
            'stats': {
                'total_calls': self._total_calls
            }
        }

    def from_checkpoint(
        self,
        data: dict[str, Any],
        function_registry: dict[str, Callable] | None = None
    ):
        """
        Restore registry state from checkpoint using hybrid/overlay approach.

        This method does NOT blindly create ToolEntry objects. Instead:
        - For tools already registered by code: overlay checkpoint metadata
        - For tools not yet registered: store in pending data for later merge

        This prevents "ghost tools" (tools without functions) from appearing.

        Args:
            data: Checkpoint data
            function_registry: Optional dict mapping tool names to functions
                              (for restoring local tool functions) - kept for compatibility
        """
        # Restore global stats
        self._total_calls = data.get('stats', {}).get('total_calls', 0)

        # Clear pending data from previous checkpoint loads
        self._pending_checkpoint_data.clear()

        # Process each tool from checkpoint
        for name, tool_data in data.get('tools', {}).items():
            if name in self._registry:
                # Fall A: Tool existiert bereits in Registry (wurde per Code geladen)
                # -> Overlay: Aktualisiere Laufzeit-Metadaten aus Checkpoint
                entry = self._registry[name]

                # Übernehme call statistics
                entry.call_count = tool_data.get('call_count', 0)

                # Übernehme timestamps
                if tool_data.get('last_called'):
                    entry.last_called = datetime.fromisoformat(tool_data['last_called'])
                if tool_data.get('created_at'):
                    entry.created_at = datetime.fromisoformat(tool_data['created_at'])

                # Merge metadata (checkpoint metadata ergänzt, überschreibt nicht komplett)
                checkpoint_metadata = tool_data.get('metadata', {})
                if checkpoint_metadata:
                    entry.metadata.update(checkpoint_metadata)

            else:
                # Fall B: Tool existiert NICHT in Registry
                # -> Speichere in pending data für spätere Registrierung
                # Erstelle KEINEN Registry-Eintrag (verhindert Geister-Tools)
                self._pending_checkpoint_data[name] = tool_data

        # Sync to RuleSet if available (nur für bereits existierende Tools)
        if self._rule_set:
            self._sync_all_to_ruleset()

    def export_for_display(self) -> str:
        """
        Export registry in human-readable format.
        Useful for debugging and status displays.
        """
        lines = ["# Tool Registry", ""]

        # Group by source
        by_source: dict[str, list[ToolEntry]] = {}
        for entry in self._registry.values():
            if entry.source not in by_source:
                by_source[entry.source] = []
            by_source[entry.source].append(entry)

        for source, entries in by_source.items():
            lines.append(f"## {source.upper()} Tools ({len(entries)})")
            lines.append("")

            for entry in sorted(entries, key=lambda e: e.name):
                flags_str = ", ".join(f for f, v in entry.flags.items() if v)
                cats_str = ", ".join(entry.category[:3])

                lines.append(f"- **{entry.name}**")
                lines.append(f"  {entry.description[:80]}...")
                lines.append(f"  Categories: {cats_str}")
                if flags_str:
                    lines.append(f"  Flags: {flags_str}")
                lines.append("")

        return "\n".join(lines)

    def register_cli_tool(
        self,
        name: str,
        executable: str,
        cli_tool_executable: str,
        executable_args: list[str] | None = None,
        category: list[str] | str | None = None,
        flags: dict[str, bool] | None = None,
        post_script_args: list[str] | None = None,
        **kwargs
    ) -> ToolEntry:
        """
        Registers a CLI command as a native tool. Validates existence,
        fetches --help for documentation, and provides a string-argument interface.
        """
        import shutil
        import subprocess
        import shlex

        # 1. Validate executable exists
        if not shutil.which(executable):
            raise FileNotFoundError(f"Executable not found in PATH: {executable}")

        # 2. Generate documentation by calling --help / -h
        doc_text = ""
        base_cmd = [executable]
        if executable_args:
            base_cmd.extend(executable_args)
        base_cmd.append(cli_tool_executable)
        for help_flag in ["--help", "-h"]:
            try:
                result = subprocess.run(
                    base_cmd + [help_flag],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                doc_text = (result.stdout or result.stderr).strip()
                if doc_text:
                    break
            except Exception:
                continue

        base_desc = f"CLI Tool wrapper for '{name} {cli_tool_executable}'."
        full_description = f"{base_desc}\n\nDocumentation:\n{doc_text}" if doc_text else base_desc

        # 3. Create the native async wrapper function for execution
        async def cli_wrapper(cli_arguments: str = "") -> str:
            """Executes the CLI tool with the provided arguments string."""
            cmd_list = [executable]
            if executable_args:
                cmd_list.extend(executable_args)

            cmd_list.append(cli_tool_executable)

            if post_script_args:
                cmd_list.extend(post_script_args)

            if cli_arguments:
                cmd_list.extend(shlex.split(cli_arguments))


            print(cmd_list)
            def _run_sync():
                return subprocess.run(
                    cmd_list,
                    capture_output=True,
                    text=True,
                    encoding='utf-8',
                    errors='replace'
                )

            # Führe den blockierenden Subprocess-Aufruf in einem Thread aus
            result = await asyncio.to_thread(_run_sync)

            if result.returncode != 0:
                error_msg = f"Command failed with exit code {result.returncode}"
                if result.stderr:
                    error_msg += f"\nSTDERR:\n{result.stderr.strip()}"
                if result.stdout:
                    error_msg += f"\nSTDOUT:\n{result.stdout.strip()}"
                raise RuntimeError(error_msg)

            return result.stdout.strip() if result.stdout else result.stderr.strip()

        # 4. Normalize categories
        cat_list = ["cli"]
        if category:
            if isinstance(category, str):
                cat_list.append(category)
            else:
                cat_list.extend(category)

        # flags_dict = {"no_thread":True}
        # if flags:
        #     flags_dict = {**flags, **flags_dict}

        # 5. Register using the existing unified registry
        return self.register(
            func=cli_wrapper,
            name=name,
            description=full_description,
            category=cat_list,
            flags=flags,
            source="cli",
            **kwargs
        )


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def create_tool_manager(rule_set: 'RuleSet | None' = None) -> ToolManager:
    """Create a ToolManager with optional RuleSet integration"""
    return ToolManager(rule_set=rule_set)

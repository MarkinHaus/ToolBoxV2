"""
OmniCore Audio I/O Integration
==============================

High-level audio processing for the ISAA Agent.

Pipeline:
    STT → ISAA (streaming, tool-augmented) → TTS → [LavaSR enhance] → Player

Player Backends:
    - LocalPlayer:  sounddevice, direct hardware output (RYZEN local)
    - WebPlayer:    async queue relay — streams WAV chunks to a websocket
                    consumer. Caller owns the consumer (FastAPI WS endpoint,
                    browser AudioWorklet, etc.). No local hardware needed.
    - NullPlayer:   silent, for testing / server-only deployments

speak() Tool Contract:
    The ISAA agent receives this tool in its tool registry. Any response
    intended for audio output MUST pass through speak(). The tool:
      1. Accepts text + optional emotion
      2. Queues it to the configured player (non-blocking)
      3. Returns immediately so the agent can continue

Version: 2.1.0
"""

import asyncio
import io
import os
import re
import wave
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import (
    Any,
    AsyncGenerator,
    Callable,
    Generator,
    Optional,
    Union,
)

from .Stt import STTBackend, STTConfig, STTResult, transcribe, transcribe_stream
from .Tts import (
    TTSBackend,
    TTSConfig,
    TTSEmotion,
    TTSResult,
    synthesize,
    synthesize_stream,
)

# Enhancer is optional — import gracefully
try:
    from .audio_enhancer import AudioEnhancer, EnhancerConfig
    _ENHANCER_AVAILABLE = True
except ImportError:
    AudioEnhancer = None  # type: ignore
    EnhancerConfig = None  # type: ignore
    _ENHANCER_AVAILABLE = False

# Type aliases
AudioData = Union[bytes, Path, str]
AsyncTextProcessor = Callable[[str], "AsyncGenerator[str, None]"]


class ProcessingMode(Enum):
    PIPELINE = "pipeline"
    NATIVE_AUDIO = "native"


class AudioQuality(Enum):
    FAST = "fast"
    BALANCED = "balanced"
    HIGH = "high"


# =============================================================================
# SENTENCE SPLITTER
# =============================================================================

_SENTENCE_RE = re.compile(r"(?<=[.!?;:])\s+")


def split_sentences(text: str, min_chars: int = 20) -> list:
    """
    Split text into TTS-ready sentence chunks.

    Short fragments (< min_chars) are merged with the next sentence
    to avoid excessive TTS calls with very short audio.

    Args:
        text: Input text to split
        min_chars: Minimum character count per chunk

    Returns:
        List of sentence strings, each ready for TTS synthesis
    """
    parts = _SENTENCE_RE.split(text.strip())
    result = []
    buffer = ""
    for part in parts:
        buffer = (buffer + " " + part).strip() if buffer else part
        if len(buffer) >= min_chars:
            result.append(buffer)
            buffer = ""
    if buffer:
        if result:
            result[-1] = result[-1] + " " + buffer
        else:
            result.append(buffer)
    return result or [text]


# =============================================================================
# AUDIO PLAYER ABSTRACTION
# =============================================================================


class AudioPlayer(ABC):
    """
    Abstract base for audio output backends.

    All players share the same async interface:
        await player.start()                         # initialize
        await player.queue_audio(bytes, metadata)    # enqueue WAV chunk
        await player.stop()                          # flush + teardown

    Subclasses handle actual delivery:
        - LocalPlayer:  writes to sounddevice hardware
        - WebPlayer:    pushes to asyncio.Queue for WS relay
        - NullPlayer:   discards audio, tracks metadata (testing)
    """

    @abstractmethod
    async def start(self) -> None:
        """Initialize the player and start any background tasks."""

    @abstractmethod
    async def stop(self) -> None:
        """Flush queued audio and release resources."""

    @abstractmethod
    async def queue_audio(self, wav_bytes: bytes, metadata: dict) -> None:
        """
        Enqueue a WAV audio chunk for output. Non-blocking.

        Args:
            wav_bytes: Complete WAV file bytes (including RIFF header)
            metadata:  Dict with keys: text, emotion, duration_s, chunk_index, session_id
        """

    @property
    @abstractmethod
    def is_active(self) -> bool:
        """True if player has queued or in-progress audio."""

    @property
    def player_type(self) -> str:
        return self.__class__.__name__


# =============================================================================
# LOCAL PLAYER (sounddevice hardware output)
# =============================================================================


class LocalPlayer(AudioPlayer):
    """
    Plays audio through local hardware via sounddevice.

    Designed for RYZEN server with audio output or developer workstations.
    Audio is played sequentially — one chunk finishes before the next starts.

    Requirements:
        pip install sounddevice numpy
    """

    def __init__(self, device=0, channels=2):
        self._queue = asyncio.Queue()
        self._task = None
        self._stop_event = asyncio.Event()
        self._playing = False
        self.device = device
        self.channels = channels

    async def start(self) -> None:
        self._stop_event.clear()
        if self._task is None or self._task.done():
            self._task = asyncio.create_task(self._worker())

    async def stop(self) -> None:
        self._stop_event.set()
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        while not self._queue.empty():
            try:
                self._queue.get_nowait()
            except Exception:
                break

    async def queue_audio(self, wav_bytes: bytes, metadata: dict) -> None:
        await self._queue.put((wav_bytes, metadata))

    async def flush(self) -> None:
        """Drop queued (not-yet-playing) audio. Best-effort barge-in support."""
        while not self._queue.empty():
            try:
                self._queue.get_nowait()
                self._queue.task_done()
            except Exception:
                break

    @property
    def is_active(self) -> bool:
        return self._playing or not self._queue.empty()

    async def _worker(self):
        try:
            import numpy as np
            import sounddevice as sd
        except ImportError as e:
            raise ImportError(
                "LocalPlayer requires sounddevice + numpy:\n"
                "  pip install sounddevice numpy\n"
                f"Original error: {e}"
            )

        while not self._stop_event.is_set():
            try:
                try:
                    wav_bytes, meta = await asyncio.wait_for(
                        self._queue.get(), timeout=0.5
                    )
                except asyncio.TimeoutError:
                    continue

                self._playing = True
                try:
                    audio_np, sample_rate = _wav_to_numpy(wav_bytes)
                    if self.channels is not None:
                        if self.channels == 2 and audio_np.ndim == 1:
                            # Mono-Audio duplizieren, um Stereo zu erzwingen
                            audio_np = np.column_stack((audio_np, audio_np))
                        elif self.channels == 1 and audio_np.ndim > 1:
                            # Falls das Gerät Mono braucht, wir aber Stereo haben -> Durchschnitt
                            audio_np = np.mean(audio_np, axis=1)
                    loop = asyncio.get_event_loop()
                    def _play(a=audio_np, sr=sample_rate, dev=self.device):
                        sd.play(a, sr, device=dev)
                        sd.wait()
                    await loop.run_in_executor(None, _play)
                except Exception as e:
                    print(f"[LocalPlayer] Playback error: {e}")
                finally:
                    self._playing = False
                    self._queue.task_done()

            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"[LocalPlayer] Worker error: {e}")
                self._playing = False

# =============================================================================
# STREAMING LOCAL PLAYER (gapless, low-latency continuous OutputStream)
# =============================================================================


class StreamingLocalPlayer(AudioPlayer):
    """Gapless, low-latency PCM output via ONE continuous sounddevice OutputStream.

    LocalPlayer does one sd.play()/sd.wait() per WAV -> audible gaps between
    streamed chunks. This keeps a single OutputStream open and feeds a ring
    buffer that the audio callback drains continuously, so Omni's 24kHz PCM
    chunks play back-to-back with ~one callback of latency. Mono int16; the
    stream sample rate is fixed at construction (Gemini live = 24000), so the
    backend's output SR MUST match (pass output_sample_rate accordingly).
    """

    def __init__(self, device=None, sample_rate: int = 24000, channels: int = 1,
                 max_buffer_s: float = 8.0):
        import threading
        self.device = device
        self.sample_rate = sample_rate
        self.channels = channels
        self._buf = bytearray()
        self._lock = threading.Lock()
        self._stream = None
        self._running = False
        # ponytail: bound the ring so playback latency can't drift unbounded.
        # Gemini bursts a whole turn faster than realtime; without a cap the
        # backlog grows every turn/restart (audible drift after ~5 restarts).
        # ceiling: keep at most max_buffer_s of audio, drop oldest on overflow.
        self.max_buffer_bytes = int(sample_rate * 2 * channels * max_buffer_s)

    async def start(self) -> None:
        import numpy as np
        import sounddevice as sd
        self._running = True
        bpf = 2 * self.channels  # bytes per frame (int16)

        def _cb(outdata, frames, time_info, status):
            need = frames * bpf
            with self._lock:
                take = bytes(self._buf[:need])
                del self._buf[:need]
            if len(take) < need:                       # underrun -> silence, no glitch
                take += b"\x00" * (need - len(take))
            outdata[:] = np.frombuffer(take, dtype=np.int16).reshape(frames, self.channels)

        self._stream = sd.OutputStream(
            samplerate=self.sample_rate, channels=self.channels, dtype="int16",
            device=self.device, callback=_cb, latency="low",
        )
        self._stream.start()

    async def stop(self) -> None:
        self._running = False
        if self._stream is not None:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception:
                pass
            self._stream = None
        with self._lock:
            self._buf.clear()

    async def queue_audio(self, wav_bytes: bytes, metadata: dict) -> None:
        try:
            arr, _sr = _wav_to_numpy(wav_bytes)   # unwrap; SR assumed == self.sample_rate
        except Exception:
            return
        with self._lock:
            self._buf.extend(arr.tobytes())
            overflow = len(self._buf) - self.max_buffer_bytes
            if overflow > 0:  # ponytail: drop oldest -> bounded latency, no drift
                del self._buf[:overflow]

    async def flush(self) -> None:
        """Drop all buffered audio immediately (barge-in / restart reset).
        Keeps the OutputStream open; just empties the ring."""
        with self._lock:
            self._buf.clear()

    @property
    def is_active(self) -> bool:
        with self._lock:
            return len(self._buf) > 0


# =============================================================================
# WEB PLAYER (async queue relay for WebSocket / HTTP streaming)
# =============================================================================


class WebPlayer(AudioPlayer):
    """
    Relays audio chunks to an async consumer (WebSocket endpoint, etc.).

    The WebPlayer does NOT handle the WebSocket itself. It maintains an
    asyncio.Queue that the caller drains. This decouples the player from
    any web framework (FastAPI, aiohttp, raw asyncio, etc.).

    Typical live usage:
        web_player = WebPlayer(max_queue=50)
        stream_player = setup_isaa_audio(agent, player_backend=web_player)
        await stream_player.start()

        # In FastAPI WebSocket handler:
        @app.websocket("/audio")
        async def ws_audio(ws: WebSocket):
            await ws.accept()
            async for chunk, meta in web_player.iter_chunks():
                await ws.send_bytes(chunk)  # raw WAV bytes per sentence

    Mock/test usage:
        player = WebPlayer(mock_mode=True)
        await player.start()
        await player.queue_audio(wav_bytes, meta)
        # Check player.received_chunks

    Wire format:
        Each chunk is a complete WAV file (with RIFF header).
        Clients can play chunks sequentially, e.g.:
            const src = new AudioBufferSourceNode(ctx);
            ctx.decodeAudioData(e.data).then(buf => { src.buffer = buf; src.start(); });

    Metadata per chunk (available to consumer via iter_chunks):
        text:        original text string
        emotion:     emotion name string
        duration_s:  float, audio duration in seconds
        chunk_index: int, monotonically increasing per session
        session_id:  str
    """

    def __init__(self, max_queue: int = 100, mock_mode: bool = False):
        self._queue = asyncio.Queue(maxsize=max_queue)
        self._running = False
        self._chunk_index = 0
        self.mock_mode = mock_mode
        # In mock_mode, chunks are stored here for test assertions
        self.received_chunks = []  # list[tuple[bytes, dict]]

    async def start(self) -> None:
        self._running = True
        self._chunk_index = 0

    async def stop(self) -> None:
        self._running = False
        if self.mock_mode:
            while not self._queue.empty():
                try:
                    chunk, meta = self._queue.get_nowait()
                    self.received_chunks.append((chunk, meta))
                except Exception:
                    break

    async def queue_audio(self, wav_bytes: bytes, metadata: dict) -> None:
        """
        Enqueue a WAV chunk for relay.

        In mock_mode: stored directly in received_chunks.
        In live mode: put into asyncio.Queue for consumer to drain.
        """
        meta = {**metadata, "chunk_index": self._chunk_index}
        self._chunk_index += 1

        if self.mock_mode:
            self.received_chunks.append((wav_bytes, meta))
        else:
            try:
                self._queue.put_nowait((wav_bytes, meta))
            except asyncio.QueueFull:
                print(f"[WebPlayer] Queue full ({self._queue.maxsize}), dropping chunk")

    async def iter_chunks(self) -> AsyncGenerator:
        """
        Async generator yielding (wav_bytes, metadata) as chunks arrive.

        Exits when stop() is called and queue is drained.

        Usage in WebSocket handler:
            async for chunk, meta in player.iter_chunks():
                await ws.send_bytes(chunk)
        """
        while self._running or not self._queue.empty():
            try:
                chunk, meta = await asyncio.wait_for(
                    self._queue.get(), timeout=0.5
                )
                yield chunk, meta
                self._queue.task_done()
            except asyncio.TimeoutError:
                if not self._running:
                    break
            except Exception as e:
                print(f"[WebPlayer] iter_chunks error: {e}")
                break

    async def get_next_chunk(self, timeout: float = 5.0):
        """Get the next chunk with timeout. Returns None on timeout."""
        try:
            return await asyncio.wait_for(self._queue.get(), timeout=timeout)
        except asyncio.TimeoutError:
            return None

    @property
    def is_active(self) -> bool:
        return not self._queue.empty()

    @property
    def queue_size(self) -> int:
        return self._queue.qsize()

    @property
    def total_chunks_sent(self) -> int:
        return self._chunk_index

    def get_received_audio_frames(self) -> bytes:
        """
        In mock_mode: concatenate raw PCM frames from all received chunks.
        Useful for asserting audio content and duration.
        """
        all_frames = b""
        for wav_bytes, _ in self.received_chunks:
            try:
                with io.BytesIO(wav_bytes) as buf:
                    with wave.open(buf, "rb") as wav:
                        all_frames += wav.readframes(wav.getnframes())
            except Exception:
                all_frames += wav_bytes
        return all_frames

    def get_received_texts(self) -> list:
        return [meta.get("text", "") for _, meta in self.received_chunks]

    def get_received_emotions(self) -> list:
        return [meta.get("emotion", "neutral") for _, meta in self.received_chunks]

    def get_total_duration(self) -> float:
        """Total audio duration in seconds across all received chunks."""
        total = 0.0
        for wav_bytes, meta in self.received_chunks:
            d = meta.get("duration_s")
            if d is not None:
                total += d
            else:
                try:
                    total += wav_duration(wav_bytes)
                except Exception:
                    pass
        return total


# =============================================================================
# NULL PLAYER (silent, for headless / test deployments)
# =============================================================================


class NullPlayer(AudioPlayer):
    """
    Discards all audio. Tracks chunks in received_chunks for assertions.

    Use in unit tests where TTS output format matters but playback doesn't.
    No external dependencies required.
    """

    def __init__(self):
        self.received_chunks = []  # list[tuple[bytes, dict]]
        self._running = False
        self._chunk_index = 0

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def queue_audio(self, wav_bytes: bytes, metadata: dict) -> None:
        meta = {**metadata, "chunk_index": self._chunk_index}
        self._chunk_index += 1
        self.received_chunks.append((wav_bytes, meta))

    @property
    def is_active(self) -> bool:
        return False

    @property
    def total_chunks(self) -> int:
        return len(self.received_chunks)

    def total_audio_bytes(self) -> int:
        return sum(len(wav) for wav, _ in self.received_chunks)

    def get_received_texts(self) -> list:
        return [meta.get("text", "") for _, meta in self.received_chunks]

    def get_received_emotions(self) -> list:
        return [meta.get("emotion", "neutral") for _, meta in self.received_chunks]


# =============================================================================
# AUDIO STREAM PLAYER (TTS queue with injected player backend)
# =============================================================================


class AudioStreamPlayer:
    """
    Manages TTS synthesis and delegates audio delivery to an AudioPlayer.

    Accepts text + emotion via queue_text(), synthesizes with the configured
    TTS backend, optionally enhances with LavaSR, then calls player.queue_audio().

    The player backend (local / web / null) is injected at construction time,
    making this class framework-agnostic.

    Example (local):
        player = AudioStreamPlayer(
            player_backend=LocalPlayer(),
            tts_config=TTSConfig(backend=TTSBackend.GROQ_TTS, voice="autumn"),
        )
        await player.start()
        await player.queue_text("Hello!", emotion=TTSEmotion.FRIENDLY)

    Example (web relay):
        web = WebPlayer(max_queue=50)
        player = AudioStreamPlayer(player_backend=web, tts_config=...)
        await player.start()
        # Consumer drains web.iter_chunks() in a separate coroutine
    """

    def __init__(
        self,
        player_backend=None,
        tts_config=None,
        enhancer=None,
        session_id: str = "default",
    ):
        self._text_queue = asyncio.Queue()
        self._task = None
        self._stop_event = asyncio.Event()
        self._synthesizing = False
        self._chunk_index = 0

        self.player = player_backend if player_backend is not None else NullPlayer()
        self.tts_config = tts_config or TTSConfig(
            backend=TTSBackend.GROQ_TTS,
            voice="autumn",
            language="de",
        )
        self.enhancer = enhancer
        self.session_id = session_id

    async def start(self) -> None:
        await self.player.start()
        self._stop_event.clear()
        if self._task is None or self._task.done():
            self._task = asyncio.create_task(self._tts_worker())

    async def stop(self) -> None:
        self._stop_event.set()
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        await self.player.stop()

    async def queue_text(
        self,
        text: str,
        emotion=None,
        style_prompt: Optional[str] = None,
    ) -> None:
        """
        Enqueue text for TTS synthesis + delivery. Non-blocking.

        Args:
            text: Text to speak.
            emotion: TTSEmotion. Defaults to NEUTRAL.
            style_prompt: Per-call override for Qwen3-TTS `instruct`.
                Ignored by other backends. Takes precedence over any
                style_prompt configured on the player's TTSConfig.
        """
        if emotion is None:
            emotion = TTSEmotion.NEUTRAL
        if text.strip():
            await self._text_queue.put((text.strip(), emotion, style_prompt))

    async def _tts_worker(self):
        """
        Background: dequeue text → TTS synthesize → optional enhance → player.queue_audio().
        TTS runs in executor to avoid blocking the event loop.
        """
        loop = asyncio.get_event_loop()

        while not self._stop_event.is_set():
            try:
                try:
                    item = await asyncio.wait_for(
                        self._text_queue.get(), timeout=0.5
                    )
                except asyncio.TimeoutError:
                    continue

                    # Queue items: (text, emotion) legacy, (text, emotion, style_prompt) new.
                    # Tolerate both so an in-flight queue across a restart won't break.
                if len(item) == 3:
                    text, emotion, style_prompt = item
                else:
                    text, emotion = item
                    style_prompt = None

                self._synthesizing = True
                try:
                    import dataclasses
                    replace_kwargs = {"emotion": emotion}
                    if style_prompt is not None:
                        replace_kwargs["qwen3_style_prompt"] = style_prompt
                    cfg = dataclasses.replace(self.tts_config, **replace_kwargs)

                    result = await loop.run_in_executor(
                        None, lambda t=text, c=cfg: synthesize(t, config=c)
                    )
                    audio_bytes = result.audio

                    if self.enhancer is not None:
                        audio_bytes = await loop.run_in_executor(
                            None, lambda b=audio_bytes: self.enhancer.enhance(b)
                        )

                    duration_s = None
                    try:
                        duration_s = wav_duration(audio_bytes)
                    except Exception:
                        pass

                    metadata = {
                        "text": text,
                        "emotion": emotion.value if hasattr(emotion, "value") else str(emotion),
                        "style_prompt": style_prompt,
                        "duration_s": duration_s,
                        "session_id": self.session_id,
                        "chunk_index": self._chunk_index,
                    }
                    self._chunk_index += 1

                    await self.player.queue_audio(audio_bytes, metadata)

                except Exception as e:
                    print(f"[AudioStreamPlayer] TTS error for '{text[:40]}': {e}")
                finally:
                    self._synthesizing = False
                    self._text_queue.task_done()

            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"[AudioStreamPlayer] Worker error: {e}")
                self._synthesizing = False

    @property
    def is_busy(self) -> bool:
        return self._synthesizing or not self._text_queue.empty() or self.player.is_active

    @property
    def pending_texts(self) -> int:
        return self._text_queue.qsize()


# =============================================================================
# AUDIO STREAM RECORDER (symmetric to AudioStreamPlayer)
# =============================================================================

class AudioStreamRecorder:
    """
    Orchestrator for the input side.

    Pipeline:
        AudioRecorder → LiveModeEngine (VAD + wake + end + partial)
                      → STT (final pass, in executor)
                      → on_transcript(text, speaker, wav_bytes)

    UI-agnostic: optional on_partial(text) callback lets the caller show
    a live spinner / streaming display.
    """

    def __init__(
        self,
        recorder: Any,                         # AudioRecorder
        live_config: Any,                      # LiveModeConfig
        stt_config: Any,                       # STTConfig — final pass
        on_transcript: Callable,               # async (text, speaker, wav) -> None
        on_partial: Optional[Callable] = None,  # async (partial_text,) -> None
        speaker_store: Optional[Any] = None,
        require_wake_word: bool = True,
        partial_stt_config: Optional[Any] = None,  # typically Parakeet fast
    ):
        from toolboxv2.mods.isaa.base.audio_io.audio_live import LiveModeEngine
        from toolboxv2.mods.isaa.base.audio_io.Stt import (
            transcribe, transcribe_partial, STTConfig, STTBackend,
        )
        self._recorder = recorder
        self._live_config = live_config
        self._stt_config = stt_config
        self._partial_stt_config = partial_stt_config or STTConfig(
            backend=STTBackend.PARAKEET, device="cpu", parakeet_preset="fast",
        )
        self._on_transcript = on_transcript
        self._on_partial = on_partial
        self._speaker_store = speaker_store
        self._require_wake = require_wake_word
        self._transcribe = transcribe
        self._transcribe_partial = transcribe_partial

        partial_cb = self._make_partial_cb() if on_partial else None
        partial_fn = self._make_partial_fn() if on_partial else None

        self._engine = LiveModeEngine(
            config=live_config,
            on_utterance=self._on_utterance_internal,
            speaker_store=speaker_store,
            recorder=recorder,
            on_partial=partial_cb,
            partial_transcriber=partial_fn,
            require_wake_word=require_wake_word,
        )
        self._active = False

    def _make_partial_cb(self) -> Callable:
        async def _cb(text: str):
            try:
                await self._on_partial(text)
            except Exception as e:
                print(f"[AudioStreamRecorder] on_partial error: {e}")
        return _cb

    def _make_partial_fn(self) -> Callable[[bytes], str]:
        cfg = self._partial_stt_config
        fn = self._transcribe_partial
        # This is called inside run_in_executor by the engine.
        def _fn(pcm: bytes) -> str:
            return fn(pcm, config=cfg)
        return _fn

    async def _on_utterance_internal(self, wav_bytes: bytes, speaker: Optional[str]):
        """Engine's final callback → run STT → fire public on_transcript."""
        import asyncio
        loop = asyncio.get_event_loop()
        try:
            result = await loop.run_in_executor(
                None,
                lambda: self._transcribe(wav_bytes, config=self._stt_config),
            )
            text = (result.text or "").strip()
            if not text:
                return
            await self._on_transcript(text, speaker, wav_bytes)
        except Exception as e:
            print(f"[AudioStreamRecorder] STT error: {e}")

    async def start(self) -> None:
        self._active = True
        await self._engine.start()

    async def stop(self) -> None:
        await self._engine.stop()
        self._active = False

    @property
    def is_active(self) -> bool:
        return self._active

    @property
    def state(self) -> str:
        return self._engine.state

    def status_line(self) -> str:
        return self._engine.status_line()


def create_listen_tool(recorder: AudioStreamRecorder):
    """
    Create an agent tool that toggles hands-free listening.

    Usage:
        agent.add_tool(create_listen_tool(recorder), name="listen")
    """
    async def listen(action: str = "status") -> str:
        """
        Control hands-free voice input.

        Args:
            action: "start" / "stop" / "status"
        """
        a = (action or "status").lower().strip()
        if a == "start":
            if recorder.is_active:
                return "[already listening]"
            await recorder.start()
            return "[listening started]"
        if a == "stop":
            if not recorder.is_active:
                return "[not listening]"
            await recorder.stop()
            return "[listening stopped]"
        return recorder.status_line()

    return listen


# =============================================================================
# AUDIO UTILITIES
# =============================================================================


def _wav_to_numpy(wav_bytes: bytes):
    """Convert WAV bytes to (numpy int16 array, sample_rate)."""
    import numpy as np
    with io.BytesIO(wav_bytes) as buf:
        with wave.open(buf, "rb") as wav:
            sr = wav.getframerate()
            frames = wav.readframes(wav.getnframes())
    return np.frombuffer(frames, dtype=np.int16), sr


def wav_duration(wav_bytes: bytes) -> float:
    """Return duration in seconds of a WAV byte buffer."""
    with io.BytesIO(wav_bytes) as buf:
        with wave.open(buf, "rb") as wav:
            return wav.getnframes() / wav.getframerate()


def wav_sample_rate(wav_bytes: bytes) -> int:
    """Return sample rate of a WAV byte buffer."""
    with io.BytesIO(wav_bytes) as buf:
        with wave.open(buf, "rb") as wav:
            return wav.getframerate()


def wav_channels(wav_bytes: bytes) -> int:
    """Return channel count of a WAV byte buffer."""
    with io.BytesIO(wav_bytes) as buf:
        with wave.open(buf, "rb") as wav:
            return wav.getnchannels()


def wav_is_valid(wav_bytes: bytes) -> bool:
    """Check if bytes are a valid WAV file."""
    if len(wav_bytes) < 12:
        return False
    return wav_bytes[:4] == b"RIFF" and wav_bytes[8:12] == b"WAVE"


def make_silent_wav(duration_s: float = 0.5, sample_rate: int = 16000) -> bytes:
    """
    Generate a silent WAV buffer. Useful for testing pipeline without real TTS.
    """
    import struct
    n_samples = int(sample_rate * duration_s)
    pcm_data = b"\x00\x00" * n_samples  # 16-bit silence
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(sample_rate)
        wav.writeframes(pcm_data)
    return buf.getvalue()


# =============================================================================
# CONFIGURATION
# =============================================================================


@dataclass
class AudioIOConfig:
    """
    Configuration for the full audio I/O pipeline.

    Player backend selection:
        player_backend_type: "local" | "web" | "null"
            - "local":  LocalPlayer (sounddevice hardware output)
            - "web":    WebPlayer (async queue relay, caller consumes)
            - "null":   NullPlayer (silent, tracks chunks for tests)
        web_player_max_queue: Queue depth for WebPlayer

    Pipeline components:
        stt_config: STT backend config
        tts_config: TTS backend config (supports INDEX_TTS + emotion)
        enable_enhancement: Toggle LavaSR post-processing
    """

    mode: ProcessingMode = ProcessingMode.PIPELINE
    quality: AudioQuality = AudioQuality.BALANCED
    language: str = "en"

    # Player
    player_backend_type: str = "null"        # "local" | "web" | "null"
    web_player_max_queue: int = 100

    # Pipeline components
    stt_config: Optional[STTConfig] = None
    tts_config: Optional[TTSConfig] = None
    enable_enhancement: bool = False
    enhancer_config: Optional[Any] = None

    # Audio settings
    sample_rate: int = 16000
    channels: int = 1

    # Streaming behavior
    speak_min_chars: int = 40
    speak_flush_timeout: float = 1.5

    # Native mode (legacy)
    native_model: str = "LiquidAI/LFM2.5-Audio-1.5B"
    native_backend: str = "transformers"
    native_device: str = "cpu"
    native_quantization: Optional[str] = None

    def __post_init__(self):
        if self.stt_config is None:
            self.stt_config = STTConfig(
                backend=STTBackend.FASTER_WHISPER,
                language=self.language,
                device="cpu",
                compute_type="int8",
            )
        if self.tts_config is None:
            self.tts_config = TTSConfig(
                backend=TTSBackend.GROQ_TTS,
                language=self.language,
            )

    def build_player(self) -> AudioPlayer:
        """Instantiate the configured player backend."""
        if self.player_backend_type == "local":
            return LocalPlayer()
        elif self.player_backend_type == "web":
            return WebPlayer(max_queue=self.web_player_max_queue)
        elif self.player_backend_type == "null":
            return NullPlayer()
        raise ValueError(
            f"Unknown player_backend_type: '{self.player_backend_type}'. "
            "Valid: 'local', 'web', 'null'"
        )

    def build_stream_player(self, session_id: str = "default") -> "AudioStreamPlayer":
        """Instantiate a fully configured AudioStreamPlayer."""
        enhancer = None
        if self.enable_enhancement and _ENHANCER_AVAILABLE and self.enhancer_config:
            enhancer = AudioEnhancer(self.enhancer_config)
        return AudioStreamPlayer(
            player_backend=self.build_player(),
            tts_config=self.tts_config,
            enhancer=enhancer,
            session_id=session_id,
        )


@dataclass
class AudioIOResult:
    text_input: str
    text_output: str
    audio_output: Optional[bytes] = None
    tool_calls: list = field(default_factory=list)
    metadata: dict = field(default_factory=dict)

    @property
    def duration(self) -> Optional[float]:
        return self.metadata.get("duration")


# =============================================================================
# SPEAK TOOL
# =============================================================================

SPEAK_TOOL_SYSTEM_PROMPT = """
## Audio Output Contract

You are operating in AUDIO MODE. The user receives your responses as speech.

**MANDATORY RULES:**
1. You MUST call the `speak` tool for EVERY response the user should hear.
2. Call `speak` EARLY — as soon as you have the first meaningful sentence.
3. Call `speak` multiple times for long responses (one call per logical paragraph).
4. The `final_answer` you return is a text transcript only; the user hears what you spoke.
5. Set `emotion` to match the content:
   - neutral: default, informational
   - friendly: greetings, casual conversation
   - excited: good news, discoveries
   - calm: explanations, instructions
   - serious: warnings, critical information
   - empathetic: apologies, user errors
   - urgent: time-critical information

**Pattern:**
speak(text="I found 3 results.", emotion="neutral")
[do more work if needed]
speak(text="Here is the most relevant one: ...", emotion="calm")
final_answer("I found 3 results. The most relevant one is ...")

Never return a final_answer without having called speak() at least once.
""".strip()


def create_speak_tool(player: AudioStreamPlayer):
    """
    Create a speak() tool function bound to an AudioStreamPlayer.

    Register on the ISAA agent:
        agent.add_tool(create_speak_tool(player), name="speak")

    Non-blocking: schedules TTS work and returns immediately.
    The player's backend handles delivery (local / web / null).
    """

    async def speak(
        text: str,
        emotion: str = "neutral",
        style_prompt: Optional[str] = None,
    ) -> str:
        """
        Speak text aloud through the audio output system.

        MUST be called for any response the user should hear.
        Returns immediately — audio plays/streams in background.

        Args:
            text: Text to speak.
            emotion: Tone preset — neutral / calm / excited / serious /
                     friendly / empathetic / urgent / custom.
                     Use "custom" together with style_prompt for Qwen3-TTS.
            style_prompt: Qwen3-TTS only. Natural-language voice/tone
                     description, e.g. "panicked robot, glitchy" or
                     "elderly professor, slightly amused".
                     Ignored by other TTS backends.

        Returns:
            "[queued for speech]"
        """
        try:
            emo = TTSEmotion(emotion.lower())
        except ValueError:
            emo = TTSEmotion.NEUTRAL

        # Qwen3 benefits from full-text context. Check active config.
        split = True
        cfg = getattr(player, "tts_config", None)
        if cfg is not None and cfg.backend == TTSBackend.QWEN3_TTS:
            split = cfg.qwen3_split_sentences

        if split:
            for sentence in split_sentences(text):
                await player.queue_text(sentence, emotion=emo, style_prompt=style_prompt)
        else:
            await player.queue_text(text, emotion=emo, style_prompt=style_prompt)

        return "[queued for speech]"

    return speak


# =============================================================================
# PIPELINE PROCESSING
# =============================================================================


async def _process_pipeline_stream(
    audio_chunks,
    st_processor,
    config,
    stream_player=None,
):
    """
    STT → ISAA stream → sentence-split TTS → player delivery.

    If stream_player is provided, audio is delivered through it.
    If not, raw WAV bytes are yielded for the caller to handle.
    """
    full_text_parts = []
    for segment in transcribe_stream(audio_chunks, config=config.stt_config):
        full_text_parts.append(segment.text)

    text_input = " ".join(full_text_parts).strip()
    if not text_input:
        return

    enhancer = None
    if config.enable_enhancement and _ENHANCER_AVAILABLE and config.enhancer_config:
        enhancer = AudioEnhancer(config.enhancer_config)

    sentence_buffer = ""

    async for text_chunk in st_processor(text_input):
        sentence_buffer += text_chunk
        match = re.search(r"[.!?;:]\s", sentence_buffer)
        if match and len(sentence_buffer[:match.end()].strip()) >= config.speak_min_chars:
            to_speak = sentence_buffer[:match.end()].strip()
            sentence_buffer = sentence_buffer[match.end():]
            async for chunk in _synthesize_and_deliver(to_speak, config, enhancer, stream_player):
                yield chunk

    if sentence_buffer.strip():
        async for chunk in _synthesize_and_deliver(
            sentence_buffer.strip(), config, enhancer, stream_player
        ):
            yield chunk


async def _synthesize_and_deliver(text, config, enhancer, stream_player):
    loop = asyncio.get_event_loop()

    result = await loop.run_in_executor(
        None, lambda: synthesize(text, config=config.tts_config)
    )
    audio_bytes = result.audio

    if enhancer is not None:
        audio_bytes = await loop.run_in_executor(
            None, lambda: enhancer.enhance(audio_bytes)
        )

    if stream_player is not None:
        await stream_player.player.queue_audio(audio_bytes, {"text": text})
    else:
        yield audio_bytes


async def _process_pipeline_raw(audio, processor, config):
    stt_result = transcribe(audio, config=config.stt_config)
    text_input = stt_result.text

    full_output = []
    async for chunk in processor(text_input):
        full_output.append(chunk)
    text_output = "".join(full_output)

    enhancer = None
    if config.enable_enhancement and _ENHANCER_AVAILABLE and config.enhancer_config:
        enhancer = AudioEnhancer(config.enhancer_config)

    tts_result = synthesize(text_output, config=config.tts_config)
    audio_bytes = tts_result.audio
    if enhancer:
        audio_bytes = enhancer.enhance(audio_bytes)

    return AudioIOResult(
        text_input=text_input,
        text_output=text_output,
        audio_output=audio_bytes,
        metadata={
            "mode": "pipeline",
            "stt_language": stt_result.language,
            "stt_duration": stt_result.duration,
            "enhanced": enhancer is not None,
            "duration": wav_duration(audio_bytes) if wav_is_valid(audio_bytes) else None,
        },
    )


# =============================================================================
# PUBLIC API
# =============================================================================


async def process_audio_raw(audio, processor, config=None, **kwargs):
    if config is None:
        config = AudioIOConfig(**kwargs)
    elif kwargs:
        config_dict = {k: v for k, v in config.__dict__.items()}
        config_dict.update(kwargs)
        config = AudioIOConfig(**config_dict)

    if config.mode == ProcessingMode.PIPELINE:
        return await _process_pipeline_raw(audio, processor, config)
    raise ValueError(f"Mode {config.mode} not supported here")


async def process_audio_stream(audio_chunks, processor, config=None, stream_player=None, **kwargs):
    if config is None:
        config = AudioIOConfig(**kwargs)
    elif kwargs:
        config_dict = {k: v for k, v in config.__dict__.items()}
        config_dict.update(kwargs)
        config = AudioIOConfig(**config_dict)

    if config.mode == ProcessingMode.PIPELINE:
        async for chunk in _process_pipeline_stream(
            audio_chunks, processor, config, stream_player
        ):
            yield chunk
    else:
        raise ValueError(f"Mode {config.mode} not supported here")


# =============================================================================
# SETUP HELPER
# =============================================================================


def setup_isaa_audio(
    agent,
    tts_config=None,
    player_backend=None,
    enable_enhancement: bool = False,
    enhancer_config=None,
    session_id: str = "default",
) -> AudioStreamPlayer:
    """
    One-call setup for ISAA audio.

    Creates AudioStreamPlayer, registers speak() tool, appends audio system prompt.

    Args:
        agent:             ISAAAgent / FlowAgent instance
        tts_config:        TTSConfig (backend, voice, emotion defaults)
        player_backend:    AudioPlayer instance. Defaults to NullPlayer.
                           Pass LocalPlayer() for hardware output.
                           Pass WebPlayer() for WS streaming.
        enable_enhancement: Enable LavaSR (requires installation)
        enhancer_config:   EnhancerConfig for LavaSR
        session_id:        Session identifier embedded in audio metadata

    Returns:
        AudioStreamPlayer — call `await player.start()` before first use.

    Examples:
        # Local hardware output
        player = setup_isaa_audio(agent, player_backend=LocalPlayer())

        # WebSocket relay
        web = WebPlayer(max_queue=50)
        player = setup_isaa_audio(agent, player_backend=web)
        await player.start()
        # async for chunk, meta in web.iter_chunks(): await ws.send_bytes(chunk)

        # Headless / testing
        null = NullPlayer()
        player = setup_isaa_audio(agent, player_backend=null)
        await player.start()
        # null.received_chunks for assertions
    """
    enhancer = None
    if enable_enhancement and _ENHANCER_AVAILABLE and enhancer_config is not None:
        enhancer = AudioEnhancer(enhancer_config)

    stream_player = AudioStreamPlayer(
        player_backend=player_backend if player_backend is not None else NullPlayer(),
        tts_config=tts_config,
        enhancer=enhancer,
        session_id=session_id,
    )

    speak_tool = create_speak_tool(stream_player)
    agent.add_tool(
        speak_tool,
        name="speak",
        description=(
            "Speak text aloud to the user. MUST be called for every response. "
            "Call early and multiple times for long answers. "
            "Set emotion to match content tone."
        ),
        category=["audio", "output"],
    )

    if hasattr(agent, "amd"):
        amd = agent.amd
        attr = "system_message" if hasattr(amd, "system_message") else "system_prompt"
        existing = getattr(amd, attr, "") or ""
        if "AUDIO MODE" not in existing:
            setattr(amd, attr, existing + "\n\n" + SPEAK_TOOL_SYSTEM_PROMPT)

    return stream_player
